#include "load.h"
#include <iostream>
#include "m1.h"
#include "StreetsDatabaseAPI.h"
#include "OSMDatabaseAPI.h"
#include "math.h"
#include <map>
#include <assert.h>
#include "globals.h"
#include "m1Helper.h"
#include "m2Helper.h"


//load and store intersections information in the street and segment array      
void load_intersections()
{    
    // Note the variables below are defined as variables of a struct
    
    // array of vectors, index is streetID, value is vector (of all intersection IDs along that street)  
    GlobalStreetData.street_intersections = new std::vector<IntersectionIdx>[GlobalStreetData.num_streets];
    
    // array of vectors, index is segment ID, value is vector (of all intersection IDs along that segment) 
    GlobalSegmentData.segment_intersections = new std::vector<IntersectionIdx>[GlobalSegmentData.num_street_segments];
    
    // array of vectors, index is intersection ID, value is vector (of all segments forming that intersection) 
    GlobalIntersectionData.intersection_segments = new std::vector<StreetSegmentIdx>[GlobalIntersectionData.num_intersections];
    
    // array of vectors, index is intersection ID, value is vector (of all LatLon of intersection id) 
    GlobalIntersectionData.intersection_position = new ezgl::point2d [GlobalIntersectionData.num_intersections];
    // array of vectors, index is intersection ID, value is vector (name of that intersection)     
    GlobalIntersectionData.intersection_name = new std::string [GlobalIntersectionData.num_intersections];
    //array of boolean. Indicate whether the intersection is highlighted
    GlobalIntersectionData.highlight = new bool [GlobalIntersectionData.num_intersections];  
    //array of boolean. Indicate whether the segment is one way
    GlobalSegmentData.one_way = new bool [GlobalSegmentData.num_street_segments];
    
    //set the initial value of map size
    GlobalMap.max_lat = getIntersectionPosition(1).latitude();
    GlobalMap.min_lat = GlobalMap.max_lat;
    GlobalMap.max_lon = getIntersectionPosition(1).longitude();
    GlobalMap.min_lon = GlobalMap.max_lon;
    GlobalMap.map_lat_avg = 0; 
    ezgl::point2d cur_point;
    // temp variables for use in for loop
    StreetSegmentIdx cur_segment;   //store current street segments
    double cur_lat;
    double cur_lon;
    for(IntersectionIdx i=0; i<=GlobalIntersectionData.num_intersections - 1; i++)
    {
        //get all segments at the intersection
        for(int j = 0; j < getNumIntersectionStreetSegment(i);j++)          
        {
            cur_segment = getIntersectionStreetSegment(i,j);
            StreetIdx cur_street = getStreetSegmentInfo(cur_segment).streetID;
            //store intersection in current segment
            GlobalSegmentData.segment_intersections[cur_segment].push_back(i); 
            //store if the segment is one way
            GlobalSegmentData.one_way[cur_segment] = getStreetSegmentInfo(cur_segment).oneWay;
            //check if already contains
            if(!(std::find(GlobalStreetData.street_intersections[cur_street].begin(), GlobalStreetData.street_intersections[cur_street].end()
                    , i)!= GlobalStreetData.street_intersections[cur_street].end()))    
            {
                GlobalStreetData.street_intersections[cur_street].push_back(i); 
            }
            //check if already contains
            if(!(std::find(GlobalIntersectionData.intersection_segments[i].begin(), GlobalIntersectionData.intersection_segments[i].end()
                    , cur_segment)!= GlobalIntersectionData.intersection_segments[i].end()))    
            {
                GlobalIntersectionData.intersection_segments[i].push_back(cur_segment);
            }
        }
        cur_point = ezgl::point2d(getIntersectionPosition(i).longitude()*kDegreeToRadian,
                                    getIntersectionPosition(i).latitude()*kDegreeToRadian);
        //store intersection position
        GlobalIntersectionData.intersection_position[i] = cur_point;
        //store intersection name
        GlobalIntersectionData.intersection_name[i] = getIntersectionName(i);
        //loop and save the max and min latitude and longtitude
        cur_lat = getIntersectionPosition(i).latitude();
        cur_lon = getIntersectionPosition(i).longitude();
//        if(i == 20 || i == 0)
//        {
//            std::cout << "now: " << GlobalIntersectionData.intersection_position[i] << std::endl;
//        }
        GlobalMap.max_lat = std::max(GlobalMap.max_lat, cur_lat);
        GlobalMap.min_lat = std::min(GlobalMap.min_lat, cur_lat);
        GlobalMap.max_lon = std::max(GlobalMap.max_lon, cur_lon);
        GlobalMap.min_lon = std::min(GlobalMap.min_lon, cur_lon);
        GlobalMap.map_lat_avg += cur_lat;   
        //default set to false
        GlobalIntersectionData.highlight[i] = false;
    }  
    GlobalMap.map_lat_avg = (GlobalMap.map_lat_avg/GlobalIntersectionData.num_intersections)*kDegreeToRadian;
//    GlobalMap.max_lon = GlobalMap.max_lon * kDegreeToRadian;
//    GlobalMap.min_lon = GlobalMap.min_lon * kDegreeToRadian;   
//    std::cout << "temp: " << temp << std::endl;
//    std::cout << "now max lon: " << GlobalMap.max_lon << std::endl;
//    std::cout << "now min lat: " << GlobalMap.min_lat << std::endl;
//    std::cout << "now min lon: " << GlobalMap.min_lon << std::endl;
    //std::cout << "now avg lat: " << GlobalMap.map_lat_avg << std::endl;
    //assert(0);
    //iterate to get intersection position from latitude longitude to x y coordinate
    for(IntersectionIdx i=0; i<=GlobalIntersectionData.num_intersections - 1; i++)
    {
        GlobalIntersectionData.intersection_position[i].x = findXOfPoint(
                    GlobalIntersectionData.intersection_position[i].x, 
                    GlobalMap.map_lat_avg);
        GlobalIntersectionData.intersection_position[i].y = findYOfPoint(
                    GlobalIntersectionData.intersection_position[i].y/kDegreeToRadian);
        //std::cout << "id: " << i << " data: " << GlobalIntersectionData.intersection_position[i].x
              //<< " and "  << GlobalIntersectionData.intersection_position[i].y << std::endl;
    }
    //get max and min of map size from latitude longitude to x y coordinate
    GlobalMap.max_lat = findYOfPoint(GlobalMap.max_lat);
    GlobalMap.min_lat = findYOfPoint(GlobalMap.min_lat);
    GlobalMap.max_lon = findXOfPoint(GlobalMap.max_lon*kDegreeToRadian, GlobalMap.map_lat_avg);
    GlobalMap.min_lon = findXOfPoint(GlobalMap.min_lon*kDegreeToRadian, GlobalMap.map_lat_avg);
//    std::cout << "now max lat: " << GlobalMap.max_lat << std::endl;
//    std::cout << "now max lon: " << GlobalMap.max_lon << std::endl;
//    std::cout << "now min lat: " << GlobalMap.min_lat << std::endl;
//    std::cout << "now min lon: " << GlobalMap.min_lon << std::endl;
    return ;
}

//load and store segments information in the street array(for covering case: segment have no intersection)
void load_streets()
{
    
    // Note the variables below are defined as variables of a struct
    
    // array of vectors, index is streetID, value is vector (of component street segment IDs)  
    GlobalStreetData.street_segments = new std::vector<StreetSegmentIdx>[GlobalStreetData.num_streets];
    GlobalStreetData.street_length = new double [GlobalStreetData.num_streets]{0};    
    // array of doubles, index is segmentID, value is segment length
    GlobalSegmentData.segment_length = new double [GlobalSegmentData.num_street_segments];   
    // array of doubles, index is segmentID, value is segment travel time
    GlobalSegmentData.segment_time=new double [GlobalSegmentData.num_street_segments];
    // array of vectors, index is segmentID, value is vector (of component segment curve point positions)
    GlobalSegmentData.points=new std::vector<LatLon>[GlobalSegmentData.num_street_segments];
    
    GlobalStreetData.road_level=new int [GlobalStreetData.num_streets];
    //int *speed=new int [1000]{0};
    //current segment information
    StreetSegmentInfo cur_segment;  
    //current length of the segment
    double cur_length;                                                      
    
    for(StreetSegmentIdx i=0; i<=GlobalSegmentData.num_street_segments - 1; i++)             
    {
        cur_segment = getStreetSegmentInfo(i);              
        cur_length = findStreetSegmentLength(i);
        StreetIdx streetId=getStreetSegmentInfo(i).streetID;

        //add segment on the belong street
        GlobalStreetData.street_segments[cur_segment.streetID].push_back(i); 
        //add length for belonging street
        GlobalStreetData.street_length[cur_segment.streetID] += cur_length; 
        //add length for segment
        GlobalSegmentData.segment_length[i] = cur_length;     
        //add major/minor road distinction
        int speed_level=0;
        while (speed_level<GlobalParameter.zoom_level_count && 
                cur_segment.speedLimit<GlobalParameter.speed_limit_of_way[speed_level])
        {
            speed_level+=1;
        }
        GlobalStreetData.road_level[streetId] = speed_level-1;
        //add curve points on the segment
        getSegmentCurvePoints(GlobalSegmentData.points[i],i);
        
        //make sure same key-value pair doesn't exist twice
        bool seen=false;                                                    
        //ignore spaces and case-insensitive
        std::string name=clearSpacesAndLowerCase(getStreetName(cur_segment.streetID));  
         //returns two iterators that points to the range of pairs with name as key
        auto range = (street_names)[name[0]-' '].equal_range(name);   
        //if there exists the same key-value pair, then don't insert
        for (auto it = range.first; it != range.second; ++it) {             
            if (it->second==cur_segment.streetID)                           
            {
                seen=true;
            }
        }
        //if this is a new pair, insert
        if (!seen)
        {
            (street_names)[name[0]-' '].insert({name,cur_segment.streetID});               
        }
        GlobalSegmentData.segment_time[i]=cur_length/(cur_segment.speedLimit);
    }
//    for (int i=0;i<1000;i++)
//    {
//        if (speed[i]!=0){
//            std::cout<<i<<": "<<speed[i]<<std::endl;
//        }
//    }
    //assert(0);
    return ;
}


// a helper function for load_OSM()
// loads three data structures
//   1. a umap, key is OSMID, value is a vector of pairs (of OSM key-value)
//   2. a vector of TourismPOI, (aka a list of all tourist attractions in the city)
//   3. a vector of SubwayPOI, (aka a list of all subway stations in the city)
void load_OSM_related_datastructures(int numEntities, int typeEntities)
{
    for (int i=0; i<numEntities; i++)
    {
        const OSMEntity *e;
        // get ptr to OSMNode
        if (typeEntities==0)  e = getNodeByIndex(i); 
        // get ptr to OSMWay
        else if (typeEntities==1)  e = getWayByIndex(i); 
        // get ptr to OSMRelation
        else if (typeEntities==2)  e = getRelationByIndex(i); 
        else e = NULL;
        OSMID id = e->id();
        
        // create a vector of pairs for this entity
        std::vector<std::pair<std::string, std::string>> temp_keyValueList;
        
        // create POI objects to store specific OSM info
        TourismPOI newTourismPOI;
        SubwayPOI newSubwayPOI;
        bool is_Tourism = false;
        bool is_Subway = false;
        
        // loop through all OSM entities
        for (int j=0; j<getTagCount(e); j++)
        {
            // push all key-value pairs of the entity into vector
            std::pair<std::string, std::string> temp_tag = getTagPair(e, j);
            temp_keyValueList.push_back(temp_tag);
            
            // if the OSM entity is a Node, it may be a tourist attraction or subway station
            // hence look for these tags
            if (typeEntities==0)
            {
                // record its name first
                if (temp_tag.first == "name") {
                    newTourismPOI.name = temp_tag.second;
                    newSubwayPOI.name = temp_tag.second;
                }
                
                // record specific info if the node is a tourist attraction
                if (temp_tag.first == "tourism" && temp_tag.second == "attraction")
                {
                    is_Tourism = true;
                    newTourismPOI.osm = id;
                    const OSMNode* eNode = getNodeByIndex(i);
                    LatLon current_POI_loc = getNodeCoords(eNode);
                    double x = findXOfPoint(current_POI_loc.longitude()*kDegreeToRadian, GlobalMap.map_lat_avg);
                    double y = findYOfPoint(current_POI_loc);
                    newTourismPOI.x_cord = x;
                    newTourismPOI.y_cord = y;
                    newTourismPOI.rating = DEFAULT_POI_RATING;
            
                // record specific info if the node is a subway station
                }
                if (temp_tag.first == "station" && temp_tag.second == "subway")
                {
                    is_Subway = true;
                    newSubwayPOI.osm = id;
                    const OSMNode* eNode = getNodeByIndex(i);
                    LatLon current_POI_loc = getNodeCoords(eNode);
                    double x = findXOfPoint(current_POI_loc.longitude()*kDegreeToRadian, GlobalMap.map_lat_avg);
                    double y = findYOfPoint(current_POI_loc);
                    newSubwayPOI.x_cord = x;
                    newSubwayPOI.y_cord = y;
                }
            }
        }
        
        // push the TourismPOI / SubwayPOI objects into a global data structure
        if (is_Tourism) GlobalToursimPOIDataFromOSM.TourismPOI_OSMID->push_back(newTourismPOI);
        if (is_Subway) GlobalSubwayPOIDataFromOSM.SubwayPOI_OSMID->push_back(newSubwayPOI);
        
        // insert into the umap this vector of pairs
        (*osmid_KeyValuePair)[id] = temp_keyValueList;
    }
}

// load the low-level OSM library for detailed POI info
void load_OSM()
{
    // umap: key is OSMID, value is a vector of pairs (of key-value)
    osmid_KeyValuePair = new std::unordered_map<OSMID, std::vector<std::pair<std::string, std::string>>>;
    
    GlobalToursimPOIDataFromOSM.TourismPOI_OSMID = new std::vector<TourismPOI>[GlobalToursimPOIDataFromOSM.num_TourismPOI];
    GlobalSubwayPOIDataFromOSM.SubwayPOI_OSMID = new std::vector<SubwayPOI>[GlobalSubwayPOIDataFromOSM.num_SubwayPOI];
    
    load_OSM_related_datastructures(getNumberOfNodes(), 0);
    load_OSM_related_datastructures(getNumberOfWays(), 1);
    load_OSM_related_datastructures(getNumberOfRelations(), 2);
 
}

// load the rating of tourist attractions with data from the web
// this function calls the get_POI_Rating_from_Web() helper function
void load_OSM_rating()
{
    // counter used to limit num of POI to display
    int countNumPOIToDisplay = 0;
    
    std::cout<< "Looking up POI ratings on the web..." <<std::endl;
    
    // loop through all pre-loaded POI in the global data structure
    for (auto i=GlobalToursimPOIDataFromOSM.TourismPOI_OSMID->begin(); i!=GlobalToursimPOIDataFromOSM.TourismPOI_OSMID->end(); i++)
    {
        
        // limit num of POI to display, for added responsiveness
        countNumPOIToDisplay++;
        if (countNumPOIToDisplay == MAX_TOURISM_POI_TO_LOAD) return;
        
        // get name of attraction
        std::string name_of_attraction = (*i).name;
        
        // retrieve rating of attraction from web
        double rating_of_attraction;
        rating_of_attraction = get_POI_Rating_from_Web(replaceSpaceWithPlus(name_of_attraction));
        
        // print rating to output
        std::cout<<name_of_attraction<<": "<<rating_of_attraction<<std::endl;
        
        // store rating in global data structure
        (*i).rating = rating_of_attraction;
    }
}

//load feature related global variables, for drawing priority using
//priority: cyan > white > yellow > green > grey
void load_feature_type(FeatureIdx id)
{
    //store each id into correct feature type structure
    if(getFeatureType(id) == FeatureType::BEACH)
    {
        GlobalFeatureData.yellow_features.push_back(id);
    }
    else if(getFeatureType(id) == FeatureType::LAKE || 
                    getFeatureType(id) == FeatureType::RIVER || 
                    getFeatureType(id) == FeatureType::STREAM ||
                    getFeatureType(id) == FeatureType::GLACIER)
    {
        GlobalFeatureData.cyan_features.push_back(id);
    }
    else if(getFeatureType(id) == FeatureType::GREENSPACE ||
                    getFeatureType(id) == FeatureType::PARK || 
                    getFeatureType(id) == FeatureType::GOLFCOURSE)
    {
        GlobalFeatureData.green_features.push_back(id);
    }
    else if(getFeatureType(id) == FeatureType::BUILDING)
    {
        GlobalFeatureData.grey_features.push_back(id);
    }
    else if(getFeatureType(id) == FeatureType::ISLAND)
    {
        GlobalFeatureData.white_features.push_back(id);
    }
}

//load feature related global variables
void load_feature()
{
    //initialize feature points
    GlobalFeatureData.feature_points = new std::vector<ezgl::point2d> [GlobalFeatureData.num_features];
    GlobalFeatureData.closed_features = new bool [GlobalFeatureData.num_features];
    GlobalFeatureData.feature_names = new std::string [GlobalFeatureData.num_features];
    GlobalFeatureData.feature_midpoint = new ezgl::point2d [GlobalFeatureData.num_features];
    //current point info
    ezgl::point2d cur_mid;
    ezgl::point2d cur_point;
    LatLon cur_LatLon;
    int x_total;
    int y_total;
    int point_count;
    
    
    
    for(int id = 0; id < GlobalFeatureData.num_features; id++)
    {
        //refresh to the next feature
        x_total = 0;
        y_total = 0;
        point_count = 0;
        //take all points into GlobalFeatureData.feature_points
        for(int cur_pointNum = 0; cur_pointNum < getNumFeaturePoints(id); cur_pointNum++)
        {
            
            cur_LatLon = getFeaturePoint(id, cur_pointNum);
            cur_point = ezgl::point2d(cur_LatLon.longitude()*kDegreeToRadian,
                                    cur_LatLon.latitude()*kDegreeToRadian);
            cur_point.x = findXOfPoint(cur_point.x, GlobalMap.map_lat_avg);
            cur_point.y = findYOfPoint(cur_point.y/kDegreeToRadian);
            GlobalFeatureData.feature_points[id].push_back(cur_point);
            //adds up all points
            x_total += cur_point.x;
            y_total += cur_point.y;
            point_count += 1;
        }
        //check if the area is closed
        if(!findFeatureArea(id))
        {
            GlobalFeatureData.closed_features[id] = false;
        }
        else
        {
            GlobalFeatureData.closed_features[id] = true;
        }
        //check if the feature has no name(duplicate names),remove duplicate names
        if(array_contains(GlobalFeatureData.feature_names, getFeatureName(id),id)) 
        {
            GlobalFeatureData.feature_names[id] = "<noname>";
        }
            
        else
            GlobalFeatureData.feature_names[id] = getFeatureName(id);
            
        //load priority
        load_feature_type(id);
        //load midpoint of polygon
        cur_mid.x = x_total / point_count;
        cur_mid.y = y_total / point_count;
        GlobalFeatureData.feature_midpoint[id] = cur_mid;
    }
    
}

