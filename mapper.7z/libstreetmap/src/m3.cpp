/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include "m3.h"
#include "globals.h"
#include "m3Helper.h"
double computePathTravelTime(const std::vector<StreetSegmentIdx>& path, 
                             const double turn_penalty){
    double answer=0;
    if (!path.size())
    {
        return 0; // there is no path at all
    }
    StreetIdx current_street;
    StreetIdx prev_street;
    int count=0;
    
    for (auto segment : path)
    {
        if (!count)
        {
            count ++;
            prev_street=getStreetSegmentInfo(segment).streetID;
        }else{
            prev_street=current_street;           
        }
        current_street=getStreetSegmentInfo(segment).streetID;
        if (prev_street!=current_street)
        {
            answer+=turn_penalty;
        }
        answer+=GlobalSegmentData.segment_time[segment];
        
    }
    return answer;
}


std::vector<StreetSegmentIdx> findPathBetweenIntersections(
                  const std::pair<IntersectionIdx, IntersectionIdx> intersect_ids,
                  const double turn_penalty){
    //get the two point
    IntersectionIdx start_point = intersect_ids.first;
    IntersectionIdx end_point = intersect_ids.second;
    //example
    start_point = 2141;
    end_point = 105556;
    double distance_to_start;
    double distance_to_end;
    double time_cost;
    std::vector<IntersectionNode> open_list;
    std::vector<IntersectionNode> closed_list;
    
    distance_to_start = 0;
    distance_to_end = intersection_distance(start_point, end_point);
    time_cost = -1;
    open_list.push_back(create_node(start_point, start_point, 0, 
            distance_to_end, time_cost, -1));
    
    bool found = false;
    IntersectionNode cur_node;
    IntersectionNode cur_child_node;
    IntersectionNode destination;
    std::vector<std::pair<IntersectionIdx, StreetSegmentIdx>> child_nodes;
    int c = 0;
    while(open_list.size() != 0 && !found)
    {
//        c++;
//        std::cout<<"loop: "<< c <<std::endl;
        cur_node = find_minimum_cost(open_list);
//        print_node(cur_node);
        child_nodes = findNearbyIntersection(cur_node.id);
        
//        print_node(cur_node);
        //check if we got final result
        std::cout<< "street segment choice: " << cur_node.previous_street_segment <<std::endl;
        for(IntersectionNode node: open_list)
        {
            if(node.id == end_point)
            {
                found = true;
//                print_node(node);
                break;
            }
        }
        //for now!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! only check the lowest time cost for priority
        //loop through all the children we get from the lowest cost parent
        for(std::pair<IntersectionIdx, StreetSegmentIdx> child : child_nodes)
        {
            cur_child_node = change_to_node(child, cur_node, intersect_ids);
            cur_child_node.node = &(cur_node);
            
            //if child exist in close list
            //condition 1: skip for we have lower cost in closed list
            //condition 2: replace for we have higher cost in closed list, make node back to open list
            if(exist_in_list(closed_list, cur_child_node))
            {
                if(lower_cost(closed_list, cur_child_node) && cur_child_node.id != start_point)
                {
//                    std::cout<<"add in closed list" <<std::endl;
                    closed_list = remove_node(closed_list, cur_child_node);
                    open_list.push_back(cur_child_node);
                } 
            }    
            //if child exist in open_list. skip
            else if(exist_in_list(open_list, cur_child_node))
            {
//                std::cout<<"exist in open list" <<std::endl;
//                continue;
            }
            //if not in open list, add to it
            else
            {
//                std::cout<<"new node" <<std::endl;
                open_list.push_back(cur_child_node);
            }         
        }
//        std::cout<<"print node:" <<std::endl;
//        for(IntersectionNode node: open_list)
//        {
//            std::cout<<"-------------------" <<std::endl;
//            print_node(node);
//        }
//        std::cout<<"print end:" <<std::endl;
        open_list = remove_node(open_list, cur_node);
        closed_list.push_back(cur_node);
//        std::cout<<"print node:" <<std::endl;
//        for(IntersectionNode node: open_list)
//        {
//            std::cout<<"-------------------" <<std::endl;
//            print_node(node);
//        }
//        std::cout<<"print end:" <<std::endl;
        //check if we got final result
        for(IntersectionNode node: open_list)
        {
            if(node.id == end_point)
            {
                found = true;
//                print_node(node);
                break;
            }
        }
    }


    
    std::vector<StreetSegmentIdx> dummy;
    open_list.clear();
    closed_list.clear();
    return dummy;
}