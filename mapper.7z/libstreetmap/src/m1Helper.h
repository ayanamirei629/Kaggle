/* 
 * File:   m1Helper.h
 * Author: Team 8 (Carl Ma, Yingge Hu, Zhuoran Wang)
 * Date:   February 2023 
 */

#include <iostream>
#include "m1.h"

//helper function for partial_name_detection
std::string clearSpacesAndLowerCase(const std::string &input);

// function for use in Polygon Area calculation
// input: a LatLon point 
// output: the Cartesian Y coordinate of the input point
double findYOfPoint(LatLon point_1);

double findYOfPoint(double lat);

// input: a longitude (double in unit of radians), and a reference "average latitude"
// output: the Cartesian X coordinate of the input point
double findXOfPoint(double lon1, double lat_avg);

// input: the Cartesian X coordinate of the input point
// output: a longitude (double in unit of radians), and a reference "average latitude"


// input: the street segment id
// output: a vector of all the LatLons of the curve points on that segment
void getSegmentCurvePoints(std::vector<LatLon>&,StreetSegmentIdx street_segment_id);


//check if array contains the existing string
bool array_contains(std::string *array, std::string target_string, int size);
