/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */
#include "m1.h"
#include "m3.h"
#include "globals.h"
#include "StreetsDatabaseAPI.h"
#include "m2Draw.h"
#include <iostream>
#include "load.h"
#include "m2Action.h"
#include "m2Helper.h"
#include <cmath>

void print_node(IntersectionNode node);

bool findPathIntersections(
                  IntersectionIdx child, IntersectionIdx parent,
                  const double turn_penalty)
{
    
    return 0;
}

//find the nearest sections and segment
std::vector<std::pair<IntersectionIdx, StreetSegmentIdx>> findNearbyIntersection(IntersectionIdx intersectionIdx)
{
    StreetSegmentIdx segment_id;
    StreetSegmentInfo segment_info;
    int segments = getNumIntersectionStreetSegment(intersectionIdx);
    std::vector<std::pair<IntersectionIdx, StreetSegmentIdx>> intersections_length;
//    std::cout<<"segments: "<< segments <<std::endl;
    for(int id =0; id < segments; id++)
    {
//        std::cout<<"id: "<< id <<std::endl;
        segment_id = getIntersectionStreetSegment(intersectionIdx, id);
        segment_info = getStreetSegmentInfo(segment_id);
//        std::cout<<"------------------" <<std::endl;
//        std::cout<<"get the segment_id:  "<< segment_info.from <<std::endl;
//        std::cout<<"get the segment_id:  "<< segment_info.to <<std::endl;
//        std::cout<<"get one way:  "<< GlobalSegmentData.one_way[segment_id] <<std::endl;
//        std::cout<<"------------------" <<std::endl;
//        std::cout<<"here: 1" <<std::endl;
        if(GlobalSegmentData.one_way[segment_id] == true && segment_info.to == intersectionIdx)
        {
//            std::cout<<"here!!!!!!!!!" <<std::endl;
            continue;
        }
        else
        {
            if(segment_info.from == intersectionIdx)
            {
                intersections_length.push_back(std::make_pair(segment_info.to, segment_id));
            }
            else
            {
                intersections_length.push_back(std::make_pair(segment_info.from, segment_id));
            }
        }
//        std::cout<<"loop end " <<std::endl;
    }  
    return intersections_length;
}

//create node
IntersectionNode create_node(IntersectionIdx id, IntersectionIdx previous_closed_id, 
        double to_start, double to_destination, double cost_time,StreetSegmentIdx segment_id)
{
    IntersectionNode node;
    node.id = id;
    node.previous_closed_id = previous_closed_id;
    node.to_start = to_start;
    node.to_destination = to_destination;
//    node.overall_estimate_count = overall_estimate_count;
    node.previous_street_segment = segment_id;
    node.cost_time = cost_time;
    return node;
}

//calculate distance between two point with x and y 
double intersection_distance(IntersectionIdx a, IntersectionIdx b)
{
    return sqrt(pow((GlobalIntersectionData.intersection_position[a].x - GlobalIntersectionData.intersection_position[b].x),2) 
            + pow((GlobalIntersectionData.intersection_position[a].y - GlobalIntersectionData.intersection_position[b].y),2));
}

//check if id exist in the vector
bool exist_in_list(std::vector<IntersectionNode> nodes, IntersectionNode node)
{
    for(IntersectionNode cur_node : nodes)
    {
        if(cur_node.id == node.id)
        {
            return true;
        }
    }
    return false;
}

//IntersectionNode create_node(IntersectionIdx id, IntersectionIdx previous_closed_id, 
//        double to_start, double to_destination, double cost_time,StreetSegmentIdx segment_id)

IntersectionNode find_minimum_cost(std::vector<IntersectionNode> open_list)
{
    //speed = distance to start point / cost time
    //estimate cost time = distance to end / speed
    double estimate_time = -1;
    double cur_time;
    IntersectionNode result;
    for(IntersectionNode node : open_list)
    {
        cur_time = node.to_destination/(node.to_start / node.cost_time) + node.cost_time;
        
        if( cur_time < estimate_time or estimate_time == -1)
        {
//            std::cout<<"-------------------" <<std::endl;
//            std::cout<<"cur_time: "<< cur_time << "estimate time: "<< estimate_time <<std::endl;
//            std::cout<<"-------------------" <<std::endl;
            estimate_time = cur_time;
            result = node;
        }
    }
//    std::cout<<"result-------------------" <<std::endl;
//    print_node(result);
//    std::cout<<"-------------------" <<std::endl;
    return result;
}

IntersectionNode change_to_node(std::pair<IntersectionIdx, StreetSegmentIdx> child_node
        , IntersectionNode parent_node, const std::pair<IntersectionIdx, IntersectionIdx> intersect_ids)
{
    IntersectionNode cur_node;
    IntersectionIdx start_point = intersect_ids.first;
    IntersectionIdx end_point = intersect_ids.second;
    double distance_to_start;
    double distance_to_end;
    double time_cost;
    IntersectionIdx parent_id;
    //!!!!!!!!!!!!!!!!!!!example
    start_point = 2141;
    end_point = 105556;
    //get child info then convert to node
    distance_to_start = intersection_distance(start_point, child_node.first);
    distance_to_end = intersection_distance(child_node.first, end_point);
    parent_id = parent_node.id;
    time_cost = parent_node.cost_time + GlobalSegmentData.segment_time[child_node.second];
            
    cur_node = create_node(child_node.first, parent_id, distance_to_start, distance_to_end,
            time_cost, child_node.second);
    return cur_node;   
}

std::vector<IntersectionNode> remove_node(std::vector<IntersectionNode> nodes, IntersectionNode node)
{
    std::cout<<"start remove: "<< node.id <<std::endl;
    for(auto it = nodes.begin(); it != nodes.end(); ++it)
    {
        
        if(it->id == node.id)
        {
            std::cout<<"found when remove, id: "<< node.id <<std::endl;
            nodes.erase(it);
            break;
        }
    }
    return nodes;
}

bool lower_cost(std::vector<IntersectionNode> nodes, IntersectionNode node)
{
        for(auto it = nodes.begin(); it != nodes.end(); ++it)
    {
        if(it->id == node.id and it->cost_time > node.cost_time)
        {
            return true;
        }
    }
    return false;
}
//IntersectionNode create_node(IntersectionIdx id, IntersectionIdx previous_closed_id, 
//        double to_start, double to_destination, double overall_estimate_count,StreetSegmentIdx segment_id)

void print_node(IntersectionNode node)
{
    std::cout<<"The id of node is: " << node.id <<std::endl;
    std::cout<<"The cost time of node is: " << node.cost_time <<std::endl;
    std::cout<<"The estimation time node is: " << node.overall_estimate_count <<std::endl;
    std::cout<<"The distance to start point is: " << node.to_start <<std::endl;
    std::cout<<"The distance to end point is: " << node.to_destination <<std::endl;
    std::cout<<"The street segment is: " << node.previous_street_segment <<std::endl;
//    std::cout<<"The parent node: " << node.node->id <<std::endl;
}