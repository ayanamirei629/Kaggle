/* 
 * File:   m2Helper.h
 * Author: Team 8 (Carl Ma, Yingge Hu, Zhuoran Wang)
 */

#include "ezgl/application.hpp"
#include "ezgl/graphics.hpp"
#include "m1.h"
#include "StreetsDatabaseAPI.h"

// draw all pre-loaded subway stations (which are also Points of Interest)
void draw_subway(ezgl::renderer *g);

//draw the intersections of the map
void draw_intersections(ezgl::renderer *g);

// draw the main canvas of the GUI
void draw_main_canvas(ezgl::renderer *g);

// draw street segments
void draw_segments(ezgl::renderer *g);

// draw all pre-loaded tourism-related Points of Interest
void draw_POI(ezgl::renderer *g);

// draw all map features (lakes, parks, etc.)
void draw_features(ezgl::renderer *g);

//Draw to screen coordinates where (0,0) is the top-left corner of the window
//These coordinates are not transformed so the object will not pan or zoom.
void screen_coordinates(ezgl::renderer *g);

// helper func for draw_segments()
void draw_segment_helper(ezgl::renderer *g, ezgl::point2d curve_point1, ezgl::point2d curve_point2, int width_factor, StreetSegmentIdx id);