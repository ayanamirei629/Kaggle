/* 
 * File:   globals.h
 * Author: Team 8 (Carl Ma, Yingge Hu, Zhuoran Wang)
 * Date:   February 2023 
 */
#include <iostream>
#include "m1.h"
#include "StreetsDatabaseAPI.h"
#include "OSMDatabaseAPI.h"
#include "math.h"
#include <map>
#include "ezgl/application.hpp"
#include "ezgl/graphics.hpp"
#include "m3.h"

//sufficient space for all kind of chars in ASCII 
constexpr int ASCII_RANGE = 256; 
constexpr int NO_RESULT=-1;
constexpr int INSUFFICENT_INPUT=-2;

constexpr int MAX_TOURISM_POI_TO_LOAD = 10;
constexpr double DEFAULT_POI_RATING = 4.0;

// all street related data structure
// see load.cpp for details of how these data structures are used 

struct StreetData 
{
    
    //streets -> intersections
    std::vector<IntersectionIdx> *street_intersections; 
    //street -> segments
    std::vector<StreetSegmentIdx> *street_segments; 
    //street -> length
    double *street_length; 
    //road_level determined by speed limit
    int *road_level; 
    //number of total street
    int num_streets; 
};
extern StreetData GlobalStreetData;

//all segment related data structure
struct SegmentData 
{
    //segments -> intersections
    std::vector<IntersectionIdx> *segment_intersections; 
    //segments -> Adjacent intersections
    std::vector<IntersectionIdx> *segment_Adjacent_intersections; 
    //segment -> length
    double *segment_length; 
    //segment -> time  
    double *segment_time;
    //segment -> one way(bool)
    bool * one_way;
    
    //Latlon of all points on the segments
    std::vector<LatLon> *points;
    
    //number of total segments
    int num_street_segments; 
};
extern SegmentData GlobalSegmentData;

//all Intersection related data structure
struct IntersectionData 
{
    //number of total intersections
    int num_intersections; 
    //intersections -> segments
    std::vector<StreetSegmentIdx> *intersection_segments; 
    //intersections -> position 
    ezgl::point2d *intersection_position;
    //intersections -> name
    std::string *intersection_name;
    //intersections -> clicked
    bool *highlight;
};
extern IntersectionData GlobalIntersectionData;

//all map related data
struct Map
{
    //size of the whole map
    double max_lat;
    double max_lon;
    double min_lat;
    double min_lon;
    double map_lat_avg;
    double zoom_level;
    double temperature=-273;
    std::string city_name;
    //1 for daytime mode -1 for night mode
    int display_mode=1;
    //major/minor road coloring mode status
    bool major_minor_color=false;
};  
extern Map GlobalMap;

//street names->street id
extern std::multimap<std::string, StreetIdx> *street_names;
//OSMID data
extern std::unordered_map<OSMID, std::vector<std::pair<std::string, std::string>>> *osmid_KeyValuePair;

//all feature related information
struct FeatureData
{
    int num_features;
    //all feature with its own points
    std::vector<ezgl::point2d> *feature_points;  
    //if the feature is closed
    bool *closed_features;
    //feature related name
    std::string *feature_names;
    //priority : draw cyan->white->yellow>green>grey
    //draw water, island, beach, grass, building
    std::vector<FeatureIdx> cyan_features;
    std::vector<FeatureIdx> yellow_features;
    std::vector<FeatureIdx> green_features;
    std::vector<FeatureIdx> grey_features;
    std::vector<FeatureIdx> white_features;
    //midpoint of each feature
    ezgl::point2d * feature_midpoint;
    
};
extern FeatureData GlobalFeatureData;

struct POIData
{
    int num_POI;
    std::vector<ezgl::point2d> *POI_points;  
};
extern POIData GlobalPOIData;

struct TourismPOI{
    OSMID osm;
    double x_cord;
    double y_cord;
    double rating;
    std::string name;
};

struct TourismPOIDataFromOSM
{
    int num_TourismPOI;
    std::vector<TourismPOI> *TourismPOI_OSMID;
    
};
extern TourismPOIDataFromOSM GlobalToursimPOIDataFromOSM;

struct SubwayPOI{
    OSMID osm;
    double x_cord;
    double y_cord;
    std::string name;
};

struct SubwayPOIDataFromOSM
{
    int num_SubwayPOI;
    std::vector<SubwayPOI> *SubwayPOI_OSMID;
    
};
extern SubwayPOIDataFromOSM GlobalSubwayPOIDataFromOSM;


//Parameters for major/minor road detection and display
struct StandardParameter
{
    int zoom_level_count=7;
    double major_road_width = 4;
    double medium_road_width = 2;
    double minor_road_width = 1;
    
    //different level represent different display content
    int zoom_level_large= 1;
    int zoom_level_medium = 3;
    int zoom_level_small = 4;
    int zoom_level_extra_small = 6;
    
    //different color representing different road size
    double road_width[7]={major_road_width,major_road_width,medium_road_width,minor_road_width,minor_road_width,minor_road_width,minor_road_width};
    ezgl::color road_color[7]={ezgl::YELLOW,ezgl::YELLOW,ezgl::GREY_55,ezgl::GREY_55,ezgl::GREY_55,ezgl::GREY_55,ezgl::GREY_55};
    ezgl::color road_night_color[7]={ezgl::YELLOW,ezgl::YELLOW,ezgl::WHITE,ezgl::WHITE,ezgl::WHITE,ezgl::WHITE,ezgl::WHITE};
    ezgl::color major_minor_color[7]={ezgl::BLACK,ezgl::BLACK,ezgl::RED,ezgl::ORANGE,ezgl::YELLOW,ezgl::GREEN,ezgl::GREEN};
 
    
    //standard speed_limit for classifying major/minor road
    int speed_limit_of_way[7]={1000,26,19,16,13,11,8};
    //zoom level requirement for displaying each type of road
    double zoom_level_limit[7]={50,50,20,10,5,2,0.5};
    
    //for drawing intersections
    int intersection_small = 1;
    int intersection_large = 3;
};
extern StandardParameter GlobalParameter;

//scale size for the graph
struct ScaleSize
{
    //actual distance parameter
    int distance[10] = {10000,5000,2000,1000,500,250,100,50,20,10};
    //related text discription
    std::string distance_parameter[10] = {"10km", "5km", "2km","1km", "500m", "250m","100m", "50m", "20m", "10m"};
    int size = 10;
};
extern ScaleSize GlobalScaleSize;

//street names->street id
struct IntersectionNode
{
    IntersectionIdx id;
    IntersectionIdx previous_closed_id;
    IntersectionNode *node;
    double to_start;
    double to_destination;
    double overall_estimate_count;
    double cost_time;
    StreetSegmentIdx previous_street_segment;
};
