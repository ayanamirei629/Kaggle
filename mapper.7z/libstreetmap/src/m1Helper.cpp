/* 
 * File:   m1Helper.cpp
 * Author: Team 8 (Carl Ma, Yingge Hu, Zhuoran Wang)
 * Date:   February 2023 
 */

#include "m1Helper.h"
#include "math.h"

//helper function for partial_name_detection
std::string clearSpacesAndLowerCase(const std::string &input) {         
    std::string output;
    for (char c : input) {
        //remove all spaces and turn letters into lower case
        if (c != ' ') {                                                 
            output += tolower(c);
        }
    }
    return output;
}

// function for use in Polygon Area calculation
// input: a LatLon point
// output: the Cartesian Y coordinate of the input point
double findYOfPoint(LatLon point_1)
{
    double lat1;
    lat1=point_1.latitude()*kDegreeToRadian;   //read lat values of the point
    double y1=kEarthRadiusInMeters*lat1;
    return y1;
}

double findYOfPoint(double lat)
{
    double lat1;
    lat1=lat*kDegreeToRadian;   //read lat values of the point
    double y1=kEarthRadiusInMeters*lat1;
    return y1;
}

// input: a longitude (double in unit of radians), and a reference "average latitude"
// output: the Cartesian X coordinate of the input point
double findXOfPoint(double lon1, double lat_avg)
{
    double x1=kEarthRadiusInMeters*lon1*cos(lat_avg); //calculate the x projection
    return x1;
}




void getSegmentCurvePoints(std::vector<LatLon>&points,StreetSegmentIdx street_segment_id)
{
    //get segment information
    StreetSegmentInfo seg_info = getStreetSegmentInfo(street_segment_id); 
    //the vector for the points on the segment
    //std::vector<LatLon>points;     
    points.push_back(getIntersectionPosition(seg_info.from));
    
    for(int i=0; i<seg_info.numCurvePoints; i++)                   
    {
        points.push_back(getStreetSegmentCurvePoint(street_segment_id, i));
    }
    
    points.push_back(getIntersectionPosition(seg_info.to));
    //return points;
}

//check if array contains the existing string
bool array_contains(std::string *array, std::string target_string, int size)
{
    for(int element = 0; element < size; element++)
    {
        if(array[element] == target_string)
            return true;
    }
    return false;
}