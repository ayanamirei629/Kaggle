/*
 * file: m2Action
 * Author: Team 8 (Carl Ma, Yingge Hu, Zhuoran Wang)
 *
 * Created on March 6, 2023, 12:02 a.m.
 */

//make the closest intersection turn red when click event happened
#include "ezgl/application.hpp"
#include "ezgl/graphics.hpp"
#include "m1.h"
#include "StreetsDatabaseAPI.h"
#include "m2Action.h"
#include "m2Helper.h"
#include "globals.h"
#include "m1Helper.h"
#include "load.h"
#include "m3.h"
std::vector<std::string> MapOptions = {"toronto_canada","london_england","beijing_china","new-delhi_india","cairo_egypt","new-york_usa","cape-town_south-africa","rio-de-janeiro_brazil","golden-horseshoe_canada","saint-helena","hamilton_canada","singapore","hong-kong_china","sydney_australia","iceland","tehran_iran","interlaken_switzerland","tokyo_japan","kyiv_ukraine"};

//show intersection information when mouse click happens
void act_on_mouse_click(ezgl::application* app, GdkEventButton* /*event*/, double x, double y)
{
    std::cout << "Mouse clicked at:" << x << " " << y <<std::endl;
  
    //find closest intersection from the click
    LatLon pos = LatLon(lat_from_y(y), lon_from_x(x));
    int id = findClosestIntersection(pos);
    
    //highlight the closest intersection
    if(GlobalIntersectionData.highlight[id])
    {
        GlobalIntersectionData.highlight[id] = false;
    }
    else
    {
        GlobalIntersectionData.highlight[id] = true;
    }
    //add message
    std::string msg = "Name: \n" + getIntersectionName(id) + "\n";
    msg += "location \nx: " + std::to_string(GlobalIntersectionData.intersection_position[id].x) + "\n" +
            " y: " + std::to_string(GlobalIntersectionData.intersection_position[id].y) + "\n" + "id: " +
            std::to_string(id) + "\n";
    std::cout<< msg <<std::endl;
    //popup information
    app->create_popup_message("Intersection Information", msg.c_str());
    app->refresh_drawing();
    //example
    findPathBetweenIntersections(std::pair<IntersectionIdx, IntersectionIdx>{0,0}, 0);
}

/**
 * Function called before the activation of the application
 * Can be used to create additional buttons, initialize the status message,
 * or connect added widgets to their callback functions
 */
void initial_setup(ezgl::application *application, bool /*new_window*/)
{
    //code for "find" button, the related callback function is "find_button_func"
    GObject *find_button = application->get_object("find_button");
    g_signal_connect(
        find_button, 
        "clicked", 
        G_CALLBACK(find_button_func), 
        application 
    );
    
    //code for night_mode_swich, the related callback function is "switch_func"
    GObject *night_mode_switch = application->get_object("switch");
    g_signal_connect(
        night_mode_switch, 
        "state-set", 
        G_CALLBACK(switch_func), 
        application 
    );
    
    //code for major_minor_switch, 
    //the related callback function is "major_minor_func"
    GObject *major_minor_switch = application->get_object("switch1");
    g_signal_connect(
        major_minor_switch, 
        "state-set", 
        G_CALLBACK(major_minor_func), 
        application 
    );
    
    
    // Update the status bar message
    application->update_message("Welcome to the BackPackers\' Guide");
    
    int row = 7;

    application->create_button("Resize POI by Rating", row++, loadRating);
    application->create_button("Show Current Temperature", row++, loadTemperature);
    
    //Code for combo_box, related function is "switch_map"
    application->create_combo_box_text("MapSelection", row++, switch_map, MapOptions);
    
}

void loadRating(GtkWidget */*widget*/, ezgl::application *application){
    load_OSM_rating();
    application->refresh_drawing();
}

void loadTemperature(GtkWidget */*widget*/, ezgl::application *application){
    double cur_temp = get_Weather_from_Web();
    std::cout << "Temperature in " << GlobalMap.city_name << " is: " << cur_temp << " degrees celsius." << std::endl;
    GlobalMap.temperature = cur_temp;
    application->refresh_drawing();
}

/**
 * Function to handle keyboard press event
 * The name of the key pressed is returned (0-9, a-z, A-Z, Up, Down, Left, Right, Shift_R, Control_L, space, Tab, ...)
 * A pointer to the application and the entire GDK event are also returned
 */
void act_on_key_press(ezgl::application *application, GdkEventKey */*event*/, char *key_name)
{
  application->update_message("Key Pressed");

  std::cout << key_name <<" key is pressed" << std::endl;
}


//function to handle night mode and daytime mode switch
void switch_func(GtkSwitch* /*self*/, gboolean state, ezgl::application* app)
{
    if (state)
    {
        app->create_popup_message("Message", "Changed to night mode");
        GlobalMap.display_mode*=-1;
    }
    else
    {
        app->create_popup_message("Message", "Changed to daytime mode");
        GlobalMap.display_mode*=-1;
    }
    
    // Redraw the main canvas
    app->refresh_drawing();
}

//function to handle night mode and daytime mode switch
void major_minor_func(GtkSwitch* /*self*/, gboolean state, ezgl::application* app)
{
    if (state)
    {
        app->create_popup_message("Note", 
                "Black: Highways\nRed to Green: Major to Minor Roads");
        app->create_popup_message("Message", 
                "Major/Minor Road mode turned on");
        GlobalMap.major_minor_color=true;
    }
    else
    {
        app->create_popup_message("Message", "Major/Minor Road mode turned off");
        GlobalMap.major_minor_color=false;
    }
    
    // Redraw the main canvas
    app->refresh_drawing();
}


void find_button_func(GtkWidget */*widget*/, ezgl::application *application)
{
    //Getting a pointer to our GtkEntry named "TextEntry"
    GtkEntry* text_entry1 = GTK_ENTRY(application->get_object("text_entry1"));
    //Getting text from our entry
    const gchar* text1 = gtk_entry_get_text(text_entry1);
    //Updating the status bar message to be the text in our entry
    GtkEntry* text_entry2 = GTK_ENTRY(application->get_object("text_entry2"));
    //Getting text from our entry
    const gchar* text2 = gtk_entry_get_text(text_entry2);
    //Updating the status bar message to be the text in our entry
    std::string text1_1=std::string(text1);
    std::string text2_1=std::string(text2);
    application->update_message("Looking for intersection of "+text1_1+" and "+text2_1);
    auto intersections=findIntersectionFromPartialName_helper(text1_1,text2_1);
    if (intersections[0]==NO_RESULT)
    {
        application->create_popup_message("Message", "No result found");
    }
    else if(intersections[0]==INSUFFICENT_INPUT)
    {
        application->create_popup_message("Message", "Insufficent partial name");
    }
    else
    {
        std::string intersection_info="Search Result: \n";
        for (auto intersection_id : intersections)
        {
            //if result exist, display in a pop-up window
            intersection_info+=getIntersectionName(intersection_id)+"\n";
            LatLon loc_info=getIntersectionPosition(intersection_id);
            intersection_info+="Latitude: "+std::to_string(loc_info.latitude()) + 
                    "\nLongitude: " +std::to_string(loc_info.longitude()) + "\n\n";
        }
        application->create_popup_message("Message", intersection_info.c_str());
    }
    
    // Redraw the main canvas
    application->refresh_drawing();
}

void switch_map(GtkComboBoxText* self, ezgl::application* app){
    auto text = gtk_combo_box_text_get_active_text(self);
    if(!text){  //Returning if the combo box is currently empty (Always check to avoid errors)
      return;
    } else {  //Updating message to reflect new combo box value.
        std::string text_string(text);
        text_string+=".streets.bin";
        if (convertFileNameToCityName(text_string)==GlobalMap.city_name) return;
        std::string loading_message="Switching to "+text_string+", please be patient...";
        
        std::cout << loading_message <<std::endl;
    
    closeMap();
    
    std::string map_path = "/cad2/ece297s/public/maps/";
    map_path += text_string;
    
    
    bool load_success = loadMap(map_path);
    if(!load_success) {
        std::cerr << "Failed to load map '" << map_path << "'\n";
    }

    std::string message="Successfully loaded map "+map_path;
    std::cout << "Successfully loaded map " << map_path << "'\n";
    app->update_message(message.c_str());

  
    ezgl::rectangle second_world({GlobalMap.min_lon, GlobalMap.min_lat},{GlobalMap.max_lon, GlobalMap.max_lat});
    
    app->change_canvas_world_coordinates("MainCanvas", second_world);
   
    app->refresh_drawing();
      g_free (text);      // gtk made a copy that we own; need to free.
    }
    
}