/*
 * file: m2Helper.h
 * Author: Team 8 (Carl Ma, Yingge Hu, Zhuoran Wang)
 *
 * Created on March 6, 2023, 12:02 a.m.
 */
#include "m1.h"
#include "ezgl/application.hpp"
#include "ezgl/graphics.hpp"

// write back function for libcurl web query for POI rating data
//static size_t write_data_POI(void *buffer, size_t size, size_t nmemb, void *userp);
    
    

// write back function for libcurl web query for city weather data
//static size_t write_data_weather(void *buffer, size_t size, size_t nmemb, void *userp);

// query the city weather on Google
// return the live, current temperature as a double
double get_Weather_from_Web();

// query the POI name on Google
// return the POI rating as a double
double get_POI_Rating_from_Web(std::string name);

// replace all spaces in a string with a plus sign
// e.g "CN Tower" -> "CN+Tower"
// the result is useful when conducting web queries
std::string replaceSpaceWithPlus(std::string str);

// helper function to convert a map_filename to a city name
// e.g. /cad2/ece297s/public/maps/toronto_canada.streets.bin -> toronto
// or   hong-hong_china.streets.bin -> hong-kong
std::string convertFileNameToCityName(std::string map_streets_database_filename);


//get latitude from y
double lat_from_y(double lat);

//get longitude from x
double lon_from_x(double lon);

//draw features with feature type info
void draw_feature_type(ezgl::renderer *g, std::vector<FeatureIdx> feature_content, ezgl::color color, int trans, bool arc);

//draw feature called by draw feature_type
void draw_feature(ezgl::renderer *g, std::vector<ezgl::point2d> cur_points, ezgl::color color, int trans, bool arc, bool closed);
std::vector<IntersectionIdx> findIntersectionFromPartialName_helper(std::string street_prefix1,std::string street_prefix2);

//find if the point is within the screen
bool point_in_zoom(double x,double y, ezgl::renderer *g);

//check if the direction of one way street is toward left(by angle rotation)
bool one_way_left(LatLon from, LatLon to);


