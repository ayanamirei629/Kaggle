/*
 * file: m2Helper.cpp
 * Author: Team 8 (Carl Ma, Yingge Hu, Zhuoran Wang)
 * 
 * This file contains helper functions for m2.cpp
 */
#include "math.h"
#include "m2Helper.h"
#include "m1Helper.h"
#include "m1.h"
#include "load.h"
#include "globals.h"
#include <string>
#include <curl/curl.h>
#include "ezgl/application.hpp"
#include "ezgl/graphics.hpp"
#include "StreetsDatabaseAPI.h"
#include "m2Action.h"

// namespace std is used in this file due to the large number of std::string
// we are aware of the risk of conflicting names, so we double checked to make
// sure none of such problems exist.
using namespace std;

// a simple structure storing tourist attraction info
// note: rating data is retrieved from web
typedef struct POI_rating {
    int rating_valid = 0;
    double rating = 0;
} POI_rating;

// a simple structure storing weather info
// note: weather data is retrieved from web
typedef struct city_weather {
    string condition;
    double tempC;
    int weather_valid = 0;
} city_weather;

// write back function for libcurl web query for POI rating data
static size_t write_data_POI(void *buffer, size_t size, size_t nmemb, void *userp) {
/* NOTE: The following code is referenced from libcurl_ex3.cpp
 *       It scans the incoming HTML for POI ratings, which is the number
 *       following the target keyword "Rated".
*/
    if (buffer && nmemb && userp)
    {
        POI_rating *ptr_POI_rating = (POI_rating *) userp;
        if (ptr_POI_rating->rating_valid) return nmemb;
        char myBuf[nmemb + 1] = {0}; // Zeroes out the array
        strncpy(myBuf, (char *)buffer, nmemb);
        myBuf[nmemb] = '\0';
        
        // find index of "Rated" in the source HTML buffer, if any
        string target ("Rated");
        string source (myBuf);
        int index_of_target = source.find(target);
        
        // if found
        if (index_of_target!=string::npos)
        {
            try
            {
                // try converting string to double
                ptr_POI_rating->rating = std::stod(source.substr(index_of_target+6, 3));
            } catch (const std::invalid_argument&)
            {
                //std::cerr << "Argument is invalid\n";
                ptr_POI_rating->rating = 4.0;
            }
            
            // set results valid
            ptr_POI_rating->rating_valid = 1;
            
            // check if the double is NaN, if so set to default rating
            if (ptr_POI_rating->rating!=ptr_POI_rating->rating)
                ptr_POI_rating->rating = DEFAULT_POI_RATING;
            
            // check for outliers, if so set to default rating
            // outlier is defined as ratings <4 or >5
            if (ptr_POI_rating->rating<4||ptr_POI_rating->rating>5)
                ptr_POI_rating->rating = DEFAULT_POI_RATING;
            return nmemb;
        }
    }
    return nmemb;
}


// write back function for libcurl web query for city weather data
static size_t write_data_weather(void *buffer, size_t size, size_t nmemb, void *userp) {
/* NOTE: The following code is referenced from libcurl_ex3.cpp
 *       It scans the incoming HTML for weather data, which is the number
 *       following the HTML tag with id="BNeawe s3v9rd AP7Wnd\".
*/
    if (buffer && nmemb && userp)
    {
        
        city_weather *ptr_city_weather = (city_weather *) userp;
        if (ptr_city_weather->weather_valid) return nmemb;
        char myBuf[nmemb + 1] = {0}; // Zeroes out the array
        strncpy(myBuf, (char *)buffer, nmemb);
        myBuf[nmemb] = '\0';
        
        // find index of the following target in the source HTML buffer, if any
        string target ("BNeawe s3v9rd AP7Wnd\">Weather");
        string source (myBuf);
        int index_of_target = source.find(target);
    
        // if found
        if (index_of_target!=string::npos)
        {
            // since we don't know the number of digits in a temperature
            // e.g. -10 has three digits
            //      and 5 has one digit
            // the following loop finds all digits until a non-digit char is seen
            string result = source.substr(index_of_target+229, 5) ;
            int i=0;
            for (i=0; i<5; i++){
                if (result[i]=='-' || (result[i]>='0' && result[i]<='9')) continue;
                else break;
            }
            
            // temperature, as a string
            string temperature = result.substr(0, i);
            
            // try converting string to double
            try
            {
            ptr_city_weather->tempC = std::stod(temperature);
            } catch (const std::invalid_argument&)
            {
                //std::cerr << "Argument is invalid\n";
                //set temperature to extreme value as a warning
                ptr_city_weather->tempC = -273;
            }
            
            // set results valid
            ptr_city_weather->weather_valid = 1;
            
            // check if the double is NaN, if so set to extreme value
            if (ptr_city_weather->tempC!=ptr_city_weather->tempC)
                ptr_city_weather->tempC = -273;
            
            return nmemb;
        }
    }
    return nmemb;
}


// helper function to convert a map_filename to a city name
// e.g. /cad2/ece297s/public/maps/toronto_canada.streets.bin -> toronto
// or   hong-hong_china.streets.bin -> hong-kong
string convertFileNameToCityName(string map_streets_database_filename)
{
    
    // remove suffix
    std::string osm_filename = map_streets_database_filename.substr(0,map_streets_database_filename.find(".streets"));
    
    // remove path prefix, if exists
    int start_idx = osm_filename.find_last_of('/');
    if (start_idx == string::npos) start_idx=0;
    else start_idx++;
    
    // remove country name, if exists
    // note that some cities do not have country names (e.g. singapore)
    int len_substr = osm_filename.find('_');
    if (len_substr == string::npos) len_substr = osm_filename.length();
    len_substr -= start_idx;
    
    // return city name, by itself, all lower case
    return osm_filename.substr(start_idx, len_substr);
}

// replace all spaces in a string with a plus sign
// e.g "CN Tower" -> "CN+Tower"
// the result is useful when conducting web queries
string replaceSpaceWithPlus(string str)
{
    // loop through chars in the string
    for (int char_idx = 0; char_idx < str.length(); char_idx++)
    {
      // replacing character to '-' with a 'space'.
      if (str[char_idx] == ' ') str[char_idx] = '+';
    }
    return str;
}


// query the POI name on Google
// return the POI rating as a double
double get_POI_Rating_from_Web(string name)
/* NOTE: The following code is referenced from libcurl_ex3.cpp
 * Only lines that we add are commented
*/
{
    CURLcode res = curl_global_init(CURL_GLOBAL_ALL);
    if (res != CURLE_OK) {
        cout << "ERROR: Unable to initialize libcurl" << endl;
        cout << curl_easy_strerror(res) << endl;
        return 0;
    }

    CURL *curlHandle = curl_easy_init();
    if ( !curlHandle ) {
        cout << "ERROR: Unable to get easy handle" << endl;
        return 0;
    } else {
        char errbuf[CURL_ERROR_SIZE] = {0};
        
        // url for Google queries
        string url = "https://www.google.com/search?q=";
        
        // combine city name with POI name in the query
        url = url + GlobalMap.city_name + "+" + name;
        
        // convert url string to char[], as required by curl
        char *url2 = new char [url.length()+1];
        strcpy(url2, url.c_str());
        
        // run query
        // the following code is from the libcurl example directly
        res = curl_easy_setopt(curlHandle, CURLOPT_URL, url2);
        POI_rating cur_POI_rating;
        if (res == CURLE_OK)
            res = curl_easy_setopt(curlHandle, CURLOPT_ERRORBUFFER, errbuf);
        if (res == CURLE_OK)
            res = curl_easy_setopt(curlHandle, CURLOPT_WRITEFUNCTION, write_data_POI);
        if (res == CURLE_OK)
            curl_easy_setopt(curlHandle, CURLOPT_WRITEDATA, &cur_POI_rating);

        if (res != CURLE_OK)
        {
            cout << "ERROR: Unable to set libcurl option" << endl;
            cout << curl_easy_strerror(res) << endl;
        } else
        {
            res = curl_easy_perform(curlHandle);
        }

        if (res == CURLE_OK)
        {
            if (cur_POI_rating.rating_valid) return cur_POI_rating.rating;
            else return 4.0;
            
        } else
        {
            cout << "ERROR: res == " << res << endl;
            cout << errbuf << endl;
        }
        curl_easy_cleanup(curlHandle);
        curlHandle = nullptr;
    }
    curl_global_cleanup();
    return 0;
}


// query the city weather on Google
// return the live, current temperature as a double
double get_Weather_from_Web()
/* NOTE: The following code is referenced from libcurl_ex3.cpp
 * Only lines that we add are commented
*/
{
    CURLcode res = curl_global_init(CURL_GLOBAL_ALL);
    if (res != CURLE_OK) {
        cout << "ERROR: Unable to initialize libcurl" << endl;
        cout << curl_easy_strerror(res) << endl;
        return 0;
    }

    CURL *curlHandle = curl_easy_init();
    if ( !curlHandle ) {
        cout << "ERROR: Unable to get easy handle" << endl;
        return 0;
    } else {
        char errbuf[CURL_ERROR_SIZE] = {0};
        
        // url for Google queries
        string url = "https://www.google.com/search?q=";
        
        // combine city name with "weather" for query
        url = url + GlobalMap.city_name + "+" + "weather";
        
        char *url2 = new char [url.length()+1];
        strcpy(url2, url.c_str());
        
        // run query
        // the following code is from the libcurl example directly
        res = curl_easy_setopt(curlHandle, CURLOPT_URL, url2);
        city_weather cur_city_weather;
        if (res == CURLE_OK)
            res = curl_easy_setopt(curlHandle, CURLOPT_ERRORBUFFER, errbuf);
        if (res == CURLE_OK)
            res = curl_easy_setopt(curlHandle, CURLOPT_WRITEFUNCTION, write_data_weather);
        if (res == CURLE_OK)
            curl_easy_setopt(curlHandle, CURLOPT_WRITEDATA, &cur_city_weather);

        if (res != CURLE_OK)
        {
            cout << "ERROR: Unable to set libcurl option" << endl;
            cout << curl_easy_strerror(res) << endl;
        } else
        {
            res = curl_easy_perform(curlHandle);
        }

        if (res == CURLE_OK)
        {
            if (cur_city_weather.weather_valid) return cur_city_weather.tempC;
            else return 0;
            
        } else
        {
            cout << "ERROR: res == " << res << endl;
            cout << errbuf << endl;
        }
        curl_easy_cleanup(curlHandle);
        curlHandle = nullptr;
    }
    curl_global_cleanup();
    return 0;
}


//find lat from y value
double lat_from_y(double y)
{
    return (y/kEarthRadiusInMeters)/kDegreeToRadian;
}


//find lon from x value
double lon_from_x(double x)
{
    return ((x/cos(GlobalMap.map_lat_avg))/kEarthRadiusInMeters)/kDegreeToRadian;
}


std::vector<IntersectionIdx> findIntersectionFromPartialName_helper(std::string street_prefix1,std::string street_prefix2)
{
    std::vector<StreetIdx> street1=findStreetIdsFromPartialStreetName(street_prefix1);
    std::vector<StreetIdx> street2=findStreetIdsFromPartialStreetName(street_prefix2);
    std::vector<IntersectionIdx> null;
    if ((street1.size()==1) && (street2.size()==1))
    {
        return findIntersectionsOfTwoStreets(street1[0],street2[0]);
    }
    else if(street1.size()==0 || street2.size()==0)
    {
        //no result found
        null.push_back(NO_RESULT);
        return null;
    }
    else
    {
        int count=0;
        std::vector<IntersectionIdx> temp;
        //check if the input partial names result in 
        //more than one possible street pair
        for (auto id1 : street1)
        {
            for (auto id2 : street2)
            {
                if (findIntersectionsOfTwoStreets(id1,id2).size()!=0)
                {
                    count+=1;
                    temp=findIntersectionsOfTwoStreets(id1,id2);
                    if (count>1){
                        break;
                    }
                }
            }
            if (count>1){
                break;
            }
        }
        if (count==0)
        {
            //No result found;
            null.push_back(NO_RESULT);
        }
        else if (count==1)
        {
            //exact result exists
            return temp;
        }
        else
        {
            //Insufficent partial name, need more information 
            null.push_back(INSUFFICENT_INPUT);
        }
        
        
        return null;
    }
}

//draw feature with relative type
void draw_feature_type(ezgl::renderer *g, std::vector<FeatureIdx> feature_content, ezgl::color color, int trans, bool arc)
{
    //if feature is building, only draw within the screen
    std::vector<ezgl::point2d> cur_points;
    bool closed;
    for(FeatureIdx id = 0; id < feature_content.size(); id++ )
    {
        cur_points = GlobalFeatureData.feature_points[feature_content[id]];
        if(point_in_zoom(cur_points[0].x, cur_points[0].y, g) || (color == ezgl::CYAN) || 
                color == ezgl::WHITE || color == ezgl::GREEN )
        {
            closed = GlobalFeatureData.closed_features[feature_content[id]];
            draw_feature(g, cur_points, color, trans, arc, closed);
        }
    }
}

//draw the feature
void draw_feature(ezgl::renderer *g, std::vector<ezgl::point2d> cur_points, ezgl::color color, int trans, bool arc, bool closed)
{
    //if one point feature, draw arc or rectangle
    g->set_color(color, trans);
    if(cur_points.size() == 1)
    {
        if(arc)
        {
            g->fill_arc(cur_points[0], 1, 0, 360);
        }
        else
        {
            g->fill_rectangle(cur_points[0], 3, 3);
        }
    } 
    else
    {
        //if closed feature, draw poly. if not, draw line
        if(closed)
        {
            g->fill_poly(cur_points);
        }
        else if(GlobalMap.zoom_level < 20)
        {
            for(int num = 0; num < cur_points.size() - 1; num++)
            {
                g->draw_line(cur_points[num], cur_points[num+1]);
            }
        }
        
    }
}

//return true if the point is within zoom
bool point_in_zoom(double x,double y, ezgl::renderer *g)
{
    ezgl::rectangle current_zoom = g->get_visible_world();
    if(x < current_zoom.right() && x > current_zoom.left()&&
            y < current_zoom.top() && y > current_zoom.bottom())
    {
        return true;
    }
        
    return false;
}

//check if the street is towards left
bool one_way_left(LatLon from, LatLon to)
{
    double from_x = findXOfPoint(from.longitude()*kDegreeToRadian, GlobalMap.map_lat_avg);
    double from_y = findYOfPoint(from.latitude());
    double to_x = findXOfPoint(to.longitude()*kDegreeToRadian, GlobalMap.map_lat_avg);
    double to_y = findYOfPoint(to.latitude());
    
    if(from_x>to_x && from_y>to_y)//1top right to bottom left
    {
        return true;
    }
    else if(from_x>to_x && from_y<to_y)//4bottom right to top left
    {
        return true;
  
    }
    else if(from_x<to_x && from_y>to_y)//2bottom left to top left
    {
        return false;
    }
    else if(from_x<to_x && from_y<to_y)//3bottom right to top left
    {
        return false;
    }
    return false;
}