/* 
 * File:   m1Helper.h
 * Author: Team 8 (Carl Ma, Yingge Hu, Zhuoran Wang)
 * Created on March 4, 2023, 2:34 a.m.
 */

#include <iostream>
#include "m2.h"
#include "ezgl/application.hpp"
#include "ezgl/graphics.hpp"
#include "m1.h"
#include "StreetsDatabaseAPI.h"
#include "OSMDatabaseAPI.h"
#include "load.h"
#include "m2Draw.h"
#include "globals.h"
#include "LatLon.h"
#include "m1Helper.h"
#include "m2Helper.h"
#include <cmath>

//draw the intersections of the map
void draw_intersections(ezgl::renderer *g)
{
//    LatLon default_latlon = LatLon();
//    LatLon position_list = *GlobalIntersectionData.intersection_position;
//    position_list.resize(GlobalIntersectionData.num_intersections);
    //double lat_avg = (GlobalMap.max_lat + GlobalMap.min_lat)*kDegreeToRadian/2; 
//    position_list.resize(GlobalIntersectionData.num_intersections);
    double x;
    double y;
    ezgl::point2d cur_intersection_loc;
    for (IntersectionIdx id = 0; id < GlobalIntersectionData.num_intersections; id++)
    {
        //std::cout << "now at: " << id << std::endl;
        //get intersection position    
        x = GlobalIntersectionData.intersection_position[id].x;
        y = GlobalIntersectionData.intersection_position[id].y;
        
        
        //define the size of circle 
        float radius;
        float width = GlobalParameter.zoom_level_large;
        float height = width;
        
        if(GlobalMap.zoom_level <= GlobalParameter.zoom_level_limit[5])     
        {
            radius = GlobalParameter.intersection_large;
        }
        else
        {
            radius = GlobalParameter.intersection_small;
        }       
        
        // monitor if the intersection is highlighted and base on the status to define the color.
        if(GlobalIntersectionData.highlight[id])
        {
            g->set_color(ezgl::RED);
            radius*=2;
        }
        else
        {
            g->set_color(ezgl::BLACK,0);
        }
        cur_intersection_loc = ezgl::point2d(x - width / 2,y - height / 2);
        g->fill_arc(cur_intersection_loc, radius, 0, 360);
        
    }
}

// draw all pre-loaded tourism-related Points of Interest
void draw_POI(ezgl::renderer *g)
{
    // counter used to limit num of POI to display
    int countNumPOIToDisplay = 0;
    
    // loop through all pre-loaded POI in the global data structure
    for (auto i=GlobalToursimPOIDataFromOSM.TourismPOI_OSMID->begin(); i!=GlobalToursimPOIDataFromOSM.TourismPOI_OSMID->end(); i++)
    {
        
        // limit num of POI to display, for added responsiveness
        countNumPOIToDisplay++;
        if (countNumPOIToDisplay == MAX_TOURISM_POI_TO_LOAD*3) return;
        
        // get rating of attraction
        double rating_of_attraction = (*i).rating;
        // get name of attraction
        std::string name_of_attraction =(*i).name;
        
        // size of the POI's label is related to its rating
        // higher rating, bigger label
        float width = std::min(60*(rating_of_attraction-3)*(rating_of_attraction-3),100.0);
        float height = width;
        float radius = width;
        
        // location of the POI's label
        ezgl::point2d cur_POI_loc_point2d = ezgl::point2d((*i).x_cord-width/2, (*i).y_cord-height/2);
    
        // visibility of label is based on zoom level
        if (GlobalMap.zoom_level<GlobalParameter.zoom_level_limit[GlobalParameter.zoom_level_large])
        {
            g->set_color(ezgl::GREEN);
            g->fill_arc(cur_POI_loc_point2d, radius, 0, 360);
            
            // name of POI is shown when zoomed further
            if (GlobalMap.zoom_level<GlobalParameter.zoom_level_limit[GlobalParameter.zoom_level_medium])
            {
                g->set_color(ezgl::BLACK);
                g->set_font_size(std::min(10,40));
                g->draw_text(cur_POI_loc_point2d, name_of_attraction);
            }
        }
    }
 }


// draw all pre-loaded subway stations (which are also Points of Interest)
void draw_subway(ezgl::renderer *g)
{
    // loop through all pre-loaded subway stations in the global data structure
    for (auto i=GlobalSubwayPOIDataFromOSM.SubwayPOI_OSMID->begin(); i!=GlobalSubwayPOIDataFromOSM.SubwayPOI_OSMID->end(); i++)
    {
        // get name of station
        std::string name_of_station =(*i).name;
        
        // standard size for all labels
        float width = 30;
        float height = width;
        float radius = width;
        
        // location of the station's label
        ezgl::point2d cur_POI_loc_point2d = ezgl::point2d((*i).x_cord - width / 2,(*i).y_cord - height / 2);
    
        // visibility of label is based on zoom level
        if (GlobalMap.zoom_level<GlobalParameter.zoom_level_limit[GlobalParameter.zoom_level_large])
        {
            g->set_color(ezgl::RED);
            g->fill_arc(cur_POI_loc_point2d, radius, 0, 360);
            
            // name of station is shown when zoomed further
            if (GlobalMap.zoom_level<GlobalParameter.zoom_level_limit[GlobalParameter.zoom_level_medium])
            {
                g->set_color(ezgl::BLACK);
                g->set_font_size(10);
                g->draw_text(cur_POI_loc_point2d, name_of_station);
            }
        }
    }
 }
    
// draw the main canvas of the GUI
void draw_main_canvas(ezgl::renderer *g)
{   
    // set initial Zoom level
    // Note: the value in the second part should be a fixed value so we can avoid re-computations
    GlobalMap.zoom_level=(g->get_visible_world().m_first.x-
                    g->get_visible_world().m_second.x)/
                    (g->get_visible_screen().m_first.x-g->
                    get_visible_screen().m_second.x);

    // call individual draw functions
    // note: order matters, we don't want certain drawings to cover others
    draw_features(g);
    draw_POI(g);
    draw_subway(g);
    draw_intersections(g);
    
    // light/dark mode
    if (GlobalMap.display_mode==-1)
    {
        g->set_color(ezgl::BLACK,255/2);
        g->fill_rectangle({GlobalMap.min_lon,GlobalMap.min_lat},{GlobalMap.max_lon,GlobalMap.max_lat});
    }
    
    // complete the rest of the drawing
    g->set_color(ezgl::BLACK);
    draw_segments(g);
    g->set_line_width(10);
    g->draw_rectangle({GlobalMap.min_lon,GlobalMap.min_lat},{GlobalMap.max_lon,GlobalMap.max_lat});
    screen_coordinates(g);
}


// draw street segments
void draw_segments(ezgl::renderer *g)
{
    double x1,x2;
    double y1,y2;
    ezgl::point2d curve_point1;
    ezgl::point2d curve_point2;
    float angle = 0;
    int count = 0;
    int offset = 5;
    double radian;
    LatLon from;
    LatLon to;
    bool oneWay;
    std::string *printed_street_names = new std::string [GlobalStreetData.num_streets]{""};
    std::string cur_street_name;
    std::string direction;
    
    for (StreetSegmentIdx id = 0; id < GlobalSegmentData.num_street_segments; id++)
    {
        StreetIdx streetId=getStreetSegmentInfo(id).streetID;
        std::vector<LatLon> points=GlobalSegmentData.points[id];
        from = getIntersectionPosition(getStreetSegmentInfo(id).from);
        to = getIntersectionPosition(getStreetSegmentInfo(id).to);
        oneWay = getStreetSegmentInfo(id).oneWay;
        cur_street_name = getStreetName(getStreetSegmentInfo(id).streetID);
        for (int pointId=1;pointId<points.size();pointId++)
        {

            x1=findXOfPoint(points[pointId-1].longitude()*kDegreeToRadian, GlobalMap.map_lat_avg);
            y1=findYOfPoint(points[pointId-1].latitude());

            x2=findXOfPoint(points[pointId].longitude()*kDegreeToRadian, GlobalMap.map_lat_avg);
            y2=findYOfPoint(points[pointId].latitude());
            
            curve_point1 = ezgl::point2d(x1,y1);
            curve_point2 = ezgl::point2d(x2,y2);
            
            // monitor how large the segment should be displayed according to zoom_level
            if (GlobalMap.zoom_level<GlobalParameter.zoom_level_limit[6])
            {
                draw_segment_helper(g, curve_point1, curve_point2, 3 , id);
            }
            else{
                if (GlobalMap.zoom_level<
                        GlobalParameter.zoom_level_limit[GlobalStreetData.road_level[streetId]])
                {
                    draw_segment_helper(g, curve_point1, curve_point2, 1 , id);
                }
                
            } 
            //condition: level< 0.5, within the graph, has street name, reasonable length, less curpoints
            if(GlobalMap.zoom_level < 0.5 && point_in_zoom((x1+x2)/2,(y1+y2)/2,g) &&
                    findStreetSegmentLength(id) > 80 &&
                    getStreetSegmentInfo(id).numCurvePoints <= 1)
            {

                    if(x1-x2 == 0)
                {
                    g->set_text_rotation(90);
                    
                }
                else
                {
                    angle = std::atan((y1-y2)/(x1-x2))/kDegreeToRadian;
                    angle = std::fmod(angle, 360.0); // convert radians to degrees
                    angle = std::round(angle * 100.0) / 100.0; // round to 2 decimal places
                    if(angle < 0)
                    {
                        angle += 360;
                    }
                    g->set_text_rotation(int(angle));
                }
                std::cout << "angle: " << angle <<std::endl;
                std::cout << "D: " << findStreetSegmentLength(id) <<std::endl;
                radian = angle *kDegreeToRadian;
                g->set_font_size(5*(5-GlobalMap.zoom_level));

                if(cur_street_name != "<unknown>" && !array_contains(printed_street_names, cur_street_name,
                        GlobalStreetData.num_streets))
                {
                    g->draw_text({(x1+x2)/2 + offset * sin(radian), (y1+y2)/2 + offset * cos(radian)},
                        cur_street_name, 400, 50);
                    printed_street_names[getStreetSegmentInfo(id).streetID] = cur_street_name;
                }

                if(oneWay)
                {
                    if (one_way_left(from,to))
                    {
                        direction = "<-";
                    }
                    else
                    {
                        direction = "->";
                    }
                    g->set_font_size(8*(5-GlobalMap.zoom_level));
                    g->draw_text({(x1+x2)/2, (y1+y2)/2},
                        direction, 400, 50);
                }
                
                g->set_font_size(1);
                count += 1;
                angle = 0;
            }
        }   
    }
    delete [] printed_street_names;
}

// helper func for draw_segments()
void draw_segment_helper(ezgl::renderer *g, ezgl::point2d curve_point1, ezgl::point2d curve_point2, int width_factor, StreetSegmentIdx id)
{
    StreetIdx streetId=getStreetSegmentInfo(id).streetID;
    g->set_color(GlobalParameter.road_color[GlobalStreetData.road_level[streetId]]);
    if (GlobalMap.display_mode==-1)
    {
        g->set_color(GlobalParameter.road_night_color[GlobalStreetData.road_level[streetId]]);
    }
    if (GlobalMap.major_minor_color)
    {
        g->set_color(GlobalParameter.major_minor_color[GlobalStreetData.road_level[streetId]]);
        width_factor*=3;
    }
    g->set_line_width(GlobalParameter.road_width[GlobalStreetData.road_level[streetId]]*width_factor);
    g->draw_line(curve_point1, curve_point2);
}


// draw all map features (lakes, parks, etc.)
void draw_features(ezgl::renderer *g)
{
    std::vector<ezgl::point2d> cur_points;
    //feature drawing
    draw_feature_type(g, GlobalFeatureData.cyan_features, ezgl::CYAN, 255/3, true);
    draw_feature_type(g, GlobalFeatureData.white_features, ezgl::WHITE, 255, true);
    draw_feature_type(g, GlobalFeatureData.yellow_features, ezgl::YELLOW, 255, true);
    draw_feature_type(g, GlobalFeatureData.green_features, ezgl::GREEN, 255/3, true);
    if(GlobalMap.zoom_level<
                    GlobalParameter.zoom_level_limit[GlobalParameter.zoom_level_small])
    {
        draw_feature_type(g, GlobalFeatureData.grey_features, ezgl::GREY_75, 255, true);
    }
    
    //feature name
    for(FeatureIdx id = 0; id < GlobalFeatureData.num_features; id++)
    {
        cur_points = GlobalFeatureData.feature_points[id];
        //print condition: zoom level < zoom_level_extra_small, name exist,
        if(point_in_zoom(cur_points[0].x, cur_points[0].y, g) && GlobalMap.zoom_level < 
                GlobalParameter.zoom_level_limit[GlobalParameter.zoom_level_extra_small] &&  
                    GlobalFeatureData.feature_names[id].compare("<noname>"))
        {
            //print feature text in the midpoint of polygon
            g->set_color(ezgl::BLACK, 255);
            g->set_font_size(10);
            g->draw_text(GlobalFeatureData.feature_midpoint[id], 
                    GlobalFeatureData.feature_names[id],400,20);
        }
    }  
}

/**
 * Draw to screen coordinates where (0,0) is the top-left corner of the window
 * These coordinates are not transformed so the object will not pan or zoom.
 */
void screen_coordinates(ezgl::renderer *g)
{
  //get screen size and actual size
  ezgl::rectangle current_zoom = g->get_visible_world();
  ezgl::rectangle current_screen = g->get_visible_screen();
  double screen_size = abs(current_screen.m_first.x - current_screen.m_second.x);
  double distance = abs(current_zoom.right() - current_zoom.left());
  //initialize for storing correct scale and size
  int cur_scale = 0;
  double actual_size = 0;
  
  //calculate the correct scale with less than 200 in the screen
  for(int element = 0; element < GlobalScaleSize.size; element++)
  {
      actual_size = GlobalScaleSize.distance[element] * screen_size / distance;
      if(actual_size > 200)
      {
          if(element ==  GlobalScaleSize.size - 1)
          {
              cur_scale = element;
          }
          continue;
      }
      else
      {
          cur_scale = element;
          break;
      }
  }

  // Set the coordinate system to SCREEN 
  g->set_coordinate_system(ezgl::SCREEN);
  // initialize elements
  g->set_text_rotation(0);
  g->set_line_width(2);
  g->set_font_size(15);
  g->set_color(ezgl::RED);
  //draw scale and whether
  g->draw_text({80, 13}, "Map Scale: " + GlobalScaleSize.distance_parameter[cur_scale]);
  g->draw_line({3, 40},{3 + actual_size, 40});
  if (GlobalMap.temperature != -273)
  g->draw_text({300, 13}, "Temperature: " + std::to_string(int(GlobalMap.temperature)) + " degrees C");
  else g->draw_text({300, 13}, "Temperature: N/A" );

  // Set the coordinate system back to WORLD
  g->set_coordinate_system(ezgl::WORLD);
  
}