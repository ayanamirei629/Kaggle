/* 
 * File:   m1.cpp
 * Author: Team 8 (Carl Ma, Yingge Hu, Zhuoran Wang)
 * Date:   February 2023 
 */

/* 
 * Copyright 2023 University of Toronto
 *
 * Permission is hereby granted, to use this software and associated 
 * documentation files (the "Software") in course work at the University 
 * of Toronto, or for personal use. Other uses are prohibited, in 
 * particular the distribution of the Software either publicly or to third 
 * parties.
 *
 * The above copyright notice and this permission notice shall be included in 
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
#include <iostream>
#include "m1.h"
#include "StreetsDatabaseAPI.h"
#include "OSMDatabaseAPI.h"
#include "math.h"
#include <map>
#include <assert.h>     /* assert */
#include "load.h"
#include "globals.h"
#include "m1Helper.h"
#include "m2Helper.h"

//initialize structures
StandardParameter GlobalParameter;
IntersectionData GlobalIntersectionData;
StreetData GlobalStreetData;
SegmentData GlobalSegmentData;
Map GlobalMap;
FeatureData GlobalFeatureData;
POIData GlobalPOIData;
TourismPOIDataFromOSM GlobalToursimPOIDataFromOSM;
SubwayPOIDataFromOSM GlobalSubwayPOIDataFromOSM;
ScaleSize GlobalScaleSize;
// array of multimaps, array index is ASCII character, multimap key is street name, value is streetID 
std::multimap<std::string,StreetIdx> *street_names=new std::multimap<std::string,StreetIdx>[ASCII_RANGE];
// key is OSMID, value is a vector of pairs (of key-value)
std::unordered_map<OSMID, std::vector<std::pair<std::string, std::string>>> *osmid_KeyValuePair;


bool loadMap(std::string map_streets_database_filename) {
    //Indicates whether the map has loaded successfully
    bool load_successful = false; 
    GlobalMap.city_name = convertFileNameToCityName(map_streets_database_filename);
    std::cout << "loadMap: " << GlobalMap.city_name << std::endl;

    // Load map related data structures
    std::string osm_filename = map_streets_database_filename.substr(0,map_streets_database_filename.find(".streets"));
    osm_filename = osm_filename + ".osm.bin";
   
   //if not load successfully, return false
    if(!loadStreetsDatabaseBIN(map_streets_database_filename) || !loadOSMDatabaseBIN(osm_filename))  
    {
        return load_successful;
    }
    //get all number range after loading
    
    // moved to m2Action.cpp
    //double cur_temp = get_Weather_from_Web();
    //std::cout << "Temperature in " << GlobalMap.city_name << " is: " << cur_temp << " degrees celsius." << std::endl;
    //GlobalMap.temperature = cur_temp;
    
    GlobalIntersectionData.num_intersections = getNumIntersections();  
    GlobalStreetData.num_streets = getNumStreets();
    GlobalSegmentData.num_street_segments = getNumStreetSegments();
    GlobalFeatureData.num_features = getNumFeatures();
    GlobalPOIData.num_POI = getNumPointsOfInterest();
    GlobalToursimPOIDataFromOSM.num_TourismPOI = getNumberOfNodes();
    GlobalSubwayPOIDataFromOSM.num_SubwayPOI = getNumberOfNodes();
    //start loading data structure
    load_intersections();
    load_streets();
    load_OSM();
    load_feature();
    //load_OSM_rating();
    //Make sure this is updated to reflect whether loading the map succeeded or failed
    load_successful = true; 

    return load_successful;
}

void closeMap() 
{
    //Clean-up map related data structures
    delete [] GlobalIntersectionData.intersection_segments;
    delete [] GlobalIntersectionData.intersection_name;
    delete [] GlobalIntersectionData.intersection_position;
    delete [] GlobalIntersectionData.highlight;
    delete [] GlobalStreetData.street_intersections;                        
    delete [] GlobalStreetData.street_segments;
    delete [] GlobalStreetData.street_length;
    delete [] GlobalSegmentData.segment_length;
    delete [] GlobalSegmentData.segment_time;
    delete [] GlobalSegmentData.segment_intersections;
    delete [] GlobalFeatureData.feature_points;
    delete [] GlobalFeatureData.closed_features;
    delete [] GlobalStreetData.road_level;
    delete osmid_KeyValuePair; 
    delete [] GlobalToursimPOIDataFromOSM.TourismPOI_OSMID;
    delete [] GlobalSubwayPOIDataFromOSM.SubwayPOI_OSMID;
    GlobalFeatureData.cyan_features.clear();
    GlobalFeatureData.green_features.clear();
    GlobalFeatureData.yellow_features.clear();
    GlobalFeatureData.white_features.clear();
    GlobalFeatureData.grey_features.clear();
    closeStreetDatabase();
    closeOSMDatabase();
}

double findDistanceBetweenTwoPoints(LatLon point_1, LatLon point_2)
{
    double lat1,lat2;          //latitude of 2 points
    double lon1,lon2;          //longitude of 2 points
    double lat_avg;            //needed in the formula 
    
    //read lat and lon values of the two point
    lon1=point_1.longitude()*kDegreeToRadian;
    lon2=point_2.longitude()*kDegreeToRadian;
    lat1=point_1.latitude()*kDegreeToRadian;   
    lat2=point_2.latitude()*kDegreeToRadian;
    lat_avg=(lat1+lat2)/2;
    
    //calculate the xy projection of two points
    double x1=findXOfPoint(lon1,lat_avg);
    double y1=findYOfPoint(point_1);
    double x2=findXOfPoint(lon2,lat_avg);
    double y2=findYOfPoint(point_2);
    
    //distance of two point
    return sqrt((y2-y1)*(y2-y1) + (x2-x1)*(x2-x1));  
}

double findStreetSegmentLength(StreetSegmentIdx street_segment_id)
{
    //get street information
    StreetSegmentInfo seg_info = getStreetSegmentInfo(street_segment_id); 
    //calculate the total length of the street
    double seg_length = 0;       
    //corner case for 0 curve point
    if(seg_info.numCurvePoints == 0)                                      
    {
        //distance between start and end point
        return findDistanceBetweenTwoPoints
                (
                    getIntersectionPosition(seg_info.from),              
                    getIntersectionPosition(seg_info.to)
                );
    }
    //distance between start and the first curve point
    seg_length += findDistanceBetweenTwoPoints
                    (
                        getIntersectionPosition(seg_info.from),              
                        getStreetSegmentCurvePoint(street_segment_id,0)
                    )
                    +
                    //distance between the last curve point and end point
                    findDistanceBetweenTwoPoints                            
                    (
                        getStreetSegmentCurvePoint(street_segment_id,seg_info.numCurvePoints - 1),              
                        getIntersectionPosition(seg_info.to)
                    );
    
    //corner case for 1 curve point
    if(seg_info.numCurvePoints == 1)                                        
    {
        return seg_length;
    }
    else
    {
        //case for curve point > 2, calculate the length between every two points
        for(int i=1; i<=seg_info.numCurvePoints - 1; i++)                   
        {
            seg_length += findDistanceBetweenTwoPoints
                    (
                        getStreetSegmentCurvePoint(street_segment_id, i - 1),
                        getStreetSegmentCurvePoint(street_segment_id, i)
                    );
        }   
    }
    //assert(0);
    return seg_length;
}

double findStreetSegmentTravelTime(StreetSegmentIdx street_segment_id)
{
    return GlobalSegmentData.segment_time[street_segment_id];
}

std::vector<IntersectionIdx> findAdjacentIntersections(IntersectionIdx intersection_id)
{
    std::vector<StreetSegmentIdx>adjacent_Segment=findStreetSegmentsOfIntersection(intersection_id);
    std::vector<IntersectionIdx> adjacent_Intersections;
    for (StreetSegmentIdx i:adjacent_Segment)
    {
        StreetSegmentInfo segmentInfo=getStreetSegmentInfo(i);
        IntersectionIdx new_intersection=(segmentInfo.to==intersection_id? segmentInfo.from:segmentInfo.to); 
        if (!(segmentInfo.oneWay && segmentInfo.to==intersection_id) &&
                !(std::find(adjacent_Intersections.begin(), adjacent_Intersections.end(), new_intersection) != adjacent_Intersections.end()))
        {
            adjacent_Intersections.push_back(new_intersection);
        }
    }
    //assert(0);
    return adjacent_Intersections;
}

IntersectionIdx findClosestIntersection(LatLon my_position)
{                                           
    //get initial distance
    int min_distance = findDistanceBetweenTwoPoints(my_position,getIntersectionPosition(0));   
    //record distance in the loop
    double current_distance;           
    //record closest intersection
    IntersectionIdx cloestintersection = 0;                                                     
    
    //loop for get distance between position and each intersection,record minimum distance and index
    for (IntersectionIdx i=0;i<GlobalIntersectionData.num_intersections;i++){                                           
        current_distance = findDistanceBetweenTwoPoints(my_position,getIntersectionPosition(i));
        if (current_distance < min_distance)                                                    
        {
            min_distance = current_distance;                                                  
            cloestintersection=i;                                                             
        }
    }
    //assert(0);
    return cloestintersection;              
}

std::vector<StreetSegmentIdx> findStreetSegmentsOfIntersection(IntersectionIdx intersection_id)
{   
    return GlobalIntersectionData.intersection_segments[intersection_id];
}
//
std::vector<IntersectionIdx> findIntersectionsOfStreet(StreetIdx street_id)
{
                                                                 
    return GlobalStreetData.street_intersections[street_id];                         
}
//
std::vector<IntersectionIdx> findIntersectionsOfTwoStreets(StreetIdx street_id1, StreetIdx street_id2)
{
    std::vector<IntersectionIdx> common_Intersection;     
    //corner case where the two inputs are the same street
    if (street_id1==street_id2)                                     
    {
        return GlobalStreetData.street_intersections[street_id1];
    }
    //get the vectors holding the intersections in each array
    std::vector<IntersectionIdx> street1=GlobalStreetData.street_intersections[street_id1];      
    std::vector<IntersectionIdx> street2=GlobalStreetData.street_intersections[street_id2];
    

    for (IntersectionIdx i : street1) 
    {
      //find the common values
      if (std::find(street2.begin(), street2.end(), i) != street2.end()) 
      {      
        common_Intersection.push_back(i);
      }
    }
    //assert(0);
    return common_Intersection;
}
//
std::vector<StreetIdx> findStreetIdsFromPartialStreetName(std::string street_prefix)
{
    
    std::vector<StreetIdx> answer;
    std::string prefix=clearSpacesAndLowerCase(street_prefix);
    // itlow points to the first one with the same prefix, itup points to the one after the prefix
    auto itlow=(street_names)[prefix[0]-' '].lower_bound (prefix);  
    auto itup=(street_names)[prefix[0]-' '].upper_bound (prefix+"~");  
    //push the indexes into the return vector
    for (auto it=itlow; it!=itup; ++it)   
    {
        answer.push_back(it->second);
    }
    //assert(0);
    return answer; 
}
//
double findStreetLength(StreetIdx street_id)
{
    return GlobalStreetData.street_length[street_id];
}

POIIdx findClosestPOI(LatLon my_position, std::string POItype)
{
    POIIdx answer = 0;
    // using Earth's radius as max distance
    double min_distance = kEarthRadiusInMeters*10; 
    double temp_distance;
    
    //get all POI
    for(int j = 0; j < getNumPointsOfInterest();j++)          
        {
            if (getPOIType(j) != POItype) continue;
            temp_distance = findDistanceBetweenTwoPoints(my_position, getPOIPosition(j));
            if (temp_distance < min_distance)
            {
                min_distance = temp_distance;
                answer = j;
            }
        }
    //assert(0);
    return answer;
}
//
double findFeatureArea(FeatureIdx feature_id)
{
    double answer =0.0;
    int NumFeaturePoints = getNumFeaturePoints(feature_id);
    // single-point feature, no area
    if (NumFeaturePoints == 1) return 0; 
    
    if (getFeaturePoint(feature_id, 0) == getFeaturePoint(feature_id, NumFeaturePoints-1))
    {
        std::vector<double> polygon_x_coord;
        std::vector<double> polygon_y_coord;
        
        // one initial for loop
        double lat_sum = 0;
        double lat_avg_polygon = 0;
        
        // note (NumFeaturePoints-1), as the repeated endpoint is not needed
        for (int i=0; i<NumFeaturePoints-1; i++)
        {
            LatLon tempLatLon = getFeaturePoint(feature_id, i);
            polygon_y_coord.push_back(findYOfPoint(tempLatLon));
            
            // note that this is a vector of lat, not x_coord, yet
            polygon_x_coord.push_back(tempLatLon.longitude()*kDegreeToRadian);
       
            lat_sum += tempLatLon.latitude()*kDegreeToRadian;
            
        }
        //assert(0);
        lat_avg_polygon = lat_sum / (NumFeaturePoints-1);
        
        // another loop to make right polygon_x_coord
        for (int i=0; i<NumFeaturePoints-1; i++)
        {
            polygon_x_coord[i] = findXOfPoint(polygon_x_coord[i], lat_avg_polygon);
        }
        
        // the last element
        int previous = NumFeaturePoints-1-1; 
        // final loop to calculate area based on shoelace formula
        for (int i=0; i<NumFeaturePoints-1; i++)
        {
            answer += (polygon_x_coord[previous] + polygon_x_coord[i]) * (polygon_y_coord[previous] - polygon_y_coord[i]);
            previous = i;  // j is previous vertex to i
        }
        answer = answer / 2.0;
        if (answer<0) answer *= -1; // absolute value
    }
    // not a polygon, no area
    else return 0; 
    
    return answer;                          
}
//
std::string getOSMNodeTagValue (OSMID OSMid, std::string key)
{
    // vector of pairs
    // this is the value of the umap corresponding to key OSMid
    std::vector<std::pair<std::string, std::string>> keyValuePairList;
    keyValuePairList = (*osmid_KeyValuePair)[OSMid];
    
    // loop thru vector to find key-value pair with key=key
    for (auto i=keyValuePairList.begin(); i!=keyValuePairList.end(); i++)
    {
        if ((*i).first==key) return (*i).second;
    }
    return "";
}
