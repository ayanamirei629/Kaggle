/*
 * file: m2Helper.h
 * Author: Team 8 (Carl Ma, Yingge Hu, Zhuoran Wang)
 */

#include "m1.h"
#include "m3.h"
//#include "globals.h"
#include "StreetsDatabaseAPI.h"
#include "m2Draw.h"
#include <iostream>
#include "load.h"
#include "m2Action.h"
#include "m2Helper.h"
 

IntersectionNode create_node(IntersectionIdx id, IntersectionIdx previous_closed_id, 
        double to_start, double to_destination, double cost_time,StreetSegmentIdx segment_id);

double intersection_distance(IntersectionIdx a, IntersectionIdx b);

bool exist_in_list(std::vector<IntersectionNode> nodes, IntersectionNode node);

std::vector<std::pair<IntersectionIdx, StreetSegmentIdx>> findNearbyIntersection(IntersectionIdx intersectionIdx);

IntersectionNode find_minimum_cost(std::vector<IntersectionNode> open_list);

IntersectionNode change_to_node(std::pair<IntersectionIdx, StreetSegmentIdx> child_node
        , IntersectionNode parent_node, const std::pair<IntersectionIdx, IntersectionIdx> intersect_ids);
        
std::vector<IntersectionNode> remove_node(std::vector<IntersectionNode> nodes, IntersectionNode node);   

bool lower_cost(std::vector<IntersectionNode> nodes, IntersectionNode node);

void print_node(IntersectionNode node);
