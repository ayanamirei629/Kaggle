/* 
 * File:   m2Action.h
 * Author: Team 8 (Carl Ma, Yingge Hu, Zhuoran Wang)
 *
 * Created on March 6, 2023, 12:02 a.m.
 */

#include "ezgl/application.hpp"
#include "ezgl/graphics.hpp"
#include "m1.h"
#include "StreetsDatabaseAPI.h"

void act_on_mouse_click(ezgl::application* app, GdkEventButton* event, double x, double y);

void act_on_key_press(ezgl::application *application, GdkEventKey */*event*/, char *key_name);

void initial_setup(ezgl::application *application, bool /*new_window*/);

void switch_func(GtkSwitch* /*self*/, gboolean state, ezgl::application* app);

void find_button_func(GtkWidget */*widget*/, ezgl::application *application);

void switch_map(GtkComboBoxText* self, ezgl::application* app);

void major_minor_func(GtkSwitch* /*self*/, gboolean state, ezgl::application* app);

void loadRating(GtkWidget */*widget*/, ezgl::application *application);

void loadTemperature(GtkWidget */*widget*/, ezgl::application *application);