/* 
 * File:   load.h
 * Author: Team 8 (Carl Ma, Yingge Hu, Zhuoran Wang)
 * Date:   February 2023 
 */

// The functions declared below are used to generate useful data structures
// upon loading the map.
// They are called in the loadMap() function.
// Data structures created by these functions are then deleted in closeMap().

#include "m1.h" 

//load data related to "intersections"
void load_intersections();

//load data related to "streets"
void load_streets();

//helper function to facilitate the load_OSM() function below
// loads three data structures
//   1. a umap, key is OSMID, value is a vector of pairs (of OSM key-value)
//   2. a vector of TourismPOI, (aka a list of all tourist attractions in the city)
//   3. a vector of SubwayPOI, (aka a list of all subway stations in the city)
void load_OSM_related_datastructures(int numEntities, int typeEntities);


// load the low-level OSM library for detailed POI info
//load data related to "OSMEntities"
void load_OSM();

void load_feature_type(FeatureIdx id);

void load_feature();

// load the rating of tourist attractions with data from the web
// this function calls the get_POI_Rating_from_Web() helper function
void load_OSM_rating();

