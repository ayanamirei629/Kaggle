# ECE297 Milestone 1

## Submission Details
Course: ECE297H (Winter 2023)
Date: February 11, 2023
Authors: Team 8 (Carl Ma, Yingge Hu, Zhouran Wang)
TA: Arash Ahmadian
CI: Peter Latka

## Table of Contents
* `libstreetmap/src`: Milestone 1 header and source files   
    
    * `m1.cpp`: Definition for all required functions in Milestone 1

    * `globals.h`: Header file for global variables

    * `load.h`: Declaration for loadMap-related functions
    * `load.cpp`: Source file for pre-processing data upon loadMap

    * `m1Helper.h`: Declaration for MISC helper functions 
    * `m1Helper.cpp`: Definition for MISC helper functions (e.g. string manipulation, math formulas)

* `libstreetmap/tests`: Custom unit tests

## License

MIT License
Copyright (c) 2023 [Carl Ma](https://github.com/carlkma), Yingge Hu, and Zhuoran Wang

> Permission is hereby granted, free of charge, to any person obtaining a copy
> of this software and associated documentation files (the "Software"), to deal
> in the Software without restriction, including without limitation the rights
> to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
> copies of the Software, and to permit persons to whom the Software is
> furnished to do so, subject to the following conditions:

> The above copyright notice and this permission notice shall be included in all
> copies or substantial portions of the Software.

> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
> IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
> FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
> LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
> OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
> SOFTWARE.

**NOTE:** This software depends on other packages that may be licensed under different open source licenses.