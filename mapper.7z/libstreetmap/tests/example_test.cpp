/* 
 * Copyright 2023 University of Toronto
 *
 * Permission is hereby granted, to use this software and associated 
 * documentation files (the "Software") in course work at the University 
 * of Toronto, or for personal use. Other uses are prohibited, in 
 * particular the distribution of the Software either publicly or to third 
 * parties.
 *
 * The above copyright notice and this permission notice shall be included in 
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
#include <UnitTest++/UnitTest++.h>
#include "/cad2/ece297s/public/include/milestones/m1.h"
#include "m1Helper.h"
#include "globals.h"
TEST(LatLonConvertToCartesianTest) {
    std::cout << "First test:" << std::endl;
    LatLon pointA (12345.6, 7890.1);
    double result = findYOfPoint(pointA);
    std::cout << result << std::endl; // should be 1.37316e+09
    CHECK(result==pointA.latitude()*kDegreeToRadian*kEarthRadiusInMeters);
}

TEST(AjacentIntersectionTest) {
    std::cout << "Second test:" << std::endl;
    std::string map_path = "/cad2/ece297s/public/maps/toronto_canada.streets.bin";
    loadMap(map_path);
    std::vector<int> result = findAdjacentIntersections(105484);
    std::vector<int> answer = {108302};
    std::cout << "result: " << result[0] << std::endl;
    CHECK(result==answer);
}

TEST(AjacentIntersectionTest2) {
    std::cout << "Third test:" << std::endl;
    std::string map_path = "/cad2/ece297s/public/maps/toronto_canada.streets.bin";
    //loadMap(map_path);
    std::vector<int> result = findAdjacentIntersections(46282);
    std::vector<int> answer = {145133};
    std::cout << "result: " << result[0] << std::endl;
    CHECK(result==answer);
}

TEST(PartialName) {
    std::cout << "Fourth test:" << std::endl;
    std::string map_path = "/cad2/ece297s/public/maps/toronto_canada.streets.bin";
    //loadMap(map_path);
    std::vector<int> result = findStreetIdsFromPartialStreetName("Old");
    std::vector<int> answer = {21921,9721,4486,4287,10470,13936,16038,15554,22145,3356,16197,1278,1919,16196,5477,13454,1967,8084,14476,6141,10057,17770,2280,6557,2206,12384,61,13070,20532,9234,19260,9447,10437,19555,14613,9540,11887,7961,19578,6541,10072,9610,19998,4028,4029,13683,20356,6353,14750,6577,4903,16185,4899,13759,6576,4768,8843,13407,8646,9380,3604,16054,9253,355,10482,6229,6209,8637,22497,14183,10083,7183,6390,4301,8563,19782,9468,4837,9646,14266,2583,12822,16795,23,5341,9951,25};
    
    std::cout << "result: " << result[0] << std::endl;
    CHECK(result==answer);
}

TEST(ClosestPOITest) {
    
    std::cout << "Fifth test:" << std::endl;
    std::string map_path = "/cad2/ece297s/public/maps/toronto_canada.streets.bin";
    loadMap(map_path);
    LatLon pointA (20, 45);
    int result = findClosestPOI(pointA, getPOIType(10));
    std::cout << result << std::endl; 
    CHECK(result==14318);
}

TEST(findStreetSegmentTravelTime) {
    std::cout << "Sixth test:" << std::endl;
    std::string map_path = "/cad2/ece297s/public/maps/toronto_canada.streets.bin";
    //loadMap(map_path);
    double result = findStreetSegmentTravelTime(2);
    double answer = GlobalSegmentData.segment_time[2];
    std::cout << "result: " << result << std::endl;
    CHECK(result==answer);
}

TEST(findStreetLength) {
    std::cout << "Sixth test:" << std::endl;
    std::string map_path = "/cad2/ece297s/public/maps/toronto_canada.streets.bin";
    //loadMap(map_path);
    double result = findStreetLength(3);
    double answer = GlobalStreetData.street_length[3];
    std::cout << "result: " << result << std::endl;
    CHECK(result==answer);
}
