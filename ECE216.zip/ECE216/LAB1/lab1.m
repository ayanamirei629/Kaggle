%1.1
%-------------------
% T=1;
% Fs=48000;
% N=T*Fs;
% t= 0 : 1/Fs : T;
% Fn=1000;
% y=sin(Fn*2*pi*t);
% plot(t,y);
% axis([0 3*48/48000 -1 1])

%1.2
%------------------------
% T=1;
% Fs = 48000;
% N = T         *Fs;
% t = 0 : 1/Fs : T;
% Fn = 1000;
% y = sin(Fn*2*pi*t);
% sound(y,Fs);
%-------------------------
% T=1;
% Fs = 48000;
% N = T*Fs;
% t = 0 : 1/Fs : T;
% Fn = 500;
% y = sin(Fn*2*pi*t);
%sound(y,Fs);
%-------------------------
% T=1;
% Fs = 48000;
% N = T*Fs;
% t = 0 : 1/Fs : T;
% Fn = 2000;
% y = sin(Fn*2*pi*t);
% sound(y,Fs);
%-------------------------
% T=1;
% Fs = 48000;
% N = T*Fs;
% t = 0 : 1/Fs : T;
% Fn = 10000;
% y = sin(Fn*2*pi*t);
% sound(y,Fs);

%1.3
%a----------------------------
[bass, fs] = audioread('bass.wav');
guitar = audioread('guitar.wav');
drums = audioread('drums.wav');
length(guitar);
%b----------------------------
duration = 5;
b = bass(1:fs*duration);
g = guitar(1:fs*duration);
d = drums(1:fs*duration);
%%sound(g,fs);
t=linspace(1,4,fs*duration)';
comp = b + t.*g + d;
sound(comp, fs);


