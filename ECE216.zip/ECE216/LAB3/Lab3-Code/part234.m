% part2 - 2
a = get_freq(9);


% -------------------
% fs = 11025;
% x1 = get_wave('C', 'm', 2, 11025);
% soundsc(get_wave('C', 'm', 2, 11025));


% x2 = get_wave('E', 'm', 2, fs);
% x3 = get_wave('G', 'm', 2, fs);
% C = x1 + x2 + x3;
% 
% G = get_chord_wave('G', 2, fs);
% Am = get_chord_wave('Am', 2, fs);
% 
% soundsc(C, fs);
% soundsc(G, fs);
% soundsc(Am, fs);


song = {'C', 1; 'C', 1; 'G', 1; 'G', 1; 'A', 1; 'A', 1; 'G', 2; 
        'F', 1; 'F', 1; 'E', 1; 'E', 1; 'D', 1; 'D', 1; 'C', 2;
        'G', 1; 'G', 1; 'F', 1; 'F', 1; 'E', 1; 'E', 1; 'D', 2;
        'G', 1; 'G', 1; 'F', 1; 'F', 1; 'E', 1; 'E', 1; 'D', 2;
        'C', 1; 'C', 1; 'G', 1; 'G', 1; 'A', 1; 'A', 1; 'G', 2;
        'F', 1; 'F', 1; 'E', 1; 'E', 1; 'D', 1; 'D', 1; 'C', 2};
beat_length = 0.5;
fs = 11025;
num_beats = 4;
% 
wave = get_song_wave(song, beat_length, fs );
soundsc(wave);

% ADSR_song = ADSR_env( wave, beat_length, num_beats, fs );
% soundsc(ADSR_song);
