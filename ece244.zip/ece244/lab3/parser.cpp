//
//  parser.cpp
//  lab3
//
//  Modified by Tarek Abdelrahman on 2020-10-04.
//  Created by Tarek Abdelrahman on 2018-08-25.
//  Copyright © 2018-2020 Tarek Abdelrahman.
//
//  Permission is hereby granted to use this code in ECE244 at
//  the University of Toronto. It is prohibited to distribute
//  this code, either publicly or to third parties.


#include <iostream>
#include <sstream>
#include <string>

using namespace std;

#include "globals.h"
#include "Shape.h"

// This is the shape array, to be dynamically allocated
Shape** shapesArray;

// The number of shapes in the database, to be incremented 
int shapeCount = 0;

// The value of the argument to the maxShapes command
int max_shapes;
int tail = 0;
int array_size = 0;

bool in_typeList(string l)
{
    for(int i=0; i < NUM_TYPES; i++)
    {
        if(shapeTypesList[i] == l)
        {
            return true;
        }
    }
    return false;
}

bool in_keyWordsList(string l)
{
    for(int i=0; i < NUM_KEYWORDS; i++)
    {
        if(keyWordsList[i] == l)
        {
            return true;
        }
    }
    return false;
}

void clearArray()
{
    for(int i=0; i< array_size; i++)
    {
        delete shapesArray[i];
    }
    delete [] shapesArray;
    tail = 0;
    //cout << "DB delete" << endl;///////////////////////
    return;
}

int find_shape(string name)
{
    for(int i=0; i<tail; i++)
    {
        if(shapesArray[i] != NULL && shapesArray[i] -> getName() == name)
        {
            return i;
        }
    }
    return -1;
}

void createDB(int size)
{
    if(shapesArray == nullptr)
    {
        //cout<< "new DB" << endl;/////////////////////////////
    }
    else
    {
        //cout << "DB exist" << endl;////////////////////////////
        clearArray();
    }  
    shapesArray = new Shape*[size];
    for(int i=0; i<size; i++)
    {
        shapesArray[i] = NULL;
    }
    array_size = size;
    cout << "New database: max shapes is " << size << endl;
}

bool stringIsDigit(string s)
{
    std::string str(s);
//    cout <<str.size()<<endl;
    for(int i =0; i < str.size();i++)
    {           
        if(!isdigit(s[i]) && i != 0)
        {
            return false;
        }
        if(i == 0 and s[i] != '-' && !isdigit(s[i]))
        {
            return false;
        }
    }
    return true;
}

bool check_info(stringstream& ss, int length, string command, string type)
{
    string info[length];
//    string s_input[3];
//    ss >> s_input[0] >> s_input[1] >> s_input[2];
//    cout<<"ss: " << s_input[0] << s_input[1] << s_input[2] << endl;///////////////////////
//    cout<<"check"<< stringIsDigit(s_input[0])<< endl;
    int value;
    for(int i=0; i<length; i++)
    {    
        if(i < length - 1 && ss.eof())
        {
            //cout<< length - 1 << " " << ss.eof() << endl;////////////////////////////
            cout<< "Error: too few arguments" << endl;
            return false;
        }
        ss >> info[i];
//        cout << info[i] << "-> info with i: "<< i << endl;////////////////////////        
        if(ss.fail() || ss.peek() == 46 || !stringIsDigit(info[i]))
        {
//            cout<< length - 1 << " " << ss.eof() << endl;////////////////////////////////////
            cout<< "Error: invalid argument" << endl;
            return false;
        }
        std::stringstream ss_temp(info[i]);
        ss_temp >> value;
        if(value < 0 || (command == "rotate" && value > 360))
        {
            cout<< "Error: invalid value" << endl;
            return false;
        } 
        if(i == length - 1 && type == "circle" && info[i] != info[i-1])
        {
            cout<< "Error: invalid value" << endl;
            return false;
        }
        if(i == length - 1 && !ss.eof())
        {
            cout<< "Error: too many arguments" << endl;
            return false;
        }
        if(i < length - 1 && ss.eof())
        {
//            cout<< i << " " << ss.eof() << endl;////////////////////////////
            cout<< "Error: too few arguments" << endl;
            return false;
        }
    }
    return true;
}

void checkInput_DB(stringstream& ss)
{
    int value;
    if(ss.eof())
    {
        cout<< "Error: too few arguments" << endl;
        return;
    }
    ss >> value;
    
    //cout << value << endl;
    //cout << ss.eof() << endl;
    //cout << ss.fail() << endl;
    //cout << ss.peek() << endl;
    
    if(ss.fail() || ss.peek() == 46 || value <= 0)
    {     
        cout << "Error: invalid argument" <<endl;
        return;
    }
    else if(!ss.eof())
    {
        cout<< "Error: too many arguments" << endl;
        return;
    }
    
    createDB(value);
    //cout<< "success" << endl;/////////////////////////
    
    return;
}

void create_shape(string name, string type, int* info)
{
//    cout<< "here2" << endl;
    for(int i=0; i < sizeof(info)/ sizeof(int); i++)
    {
        if(info[i] < 0)
        {
            cout << "Error: invalid value" << endl;
            return;
        }
    }
    //cout << info[2] << info[3] << endl;
    //cout << name << endl;
    if(type == "circle" && info[2] != info[3])
    {
        cout << "Error: invalid value" << endl;
        return;
    }
    
    shapesArray[tail] = new Shape(name, type, info[0], info[2], info[1], info[3]);
    cout << "Created " << name << ": " << type << " " << info[0] << " " << info[1] << " ";
    cout << info[2] << " " << info[3] << endl;
    tail += 1;
    return;
}

void checkInput_create(stringstream& ss)
{
//    cout<< "here1" << endl;
    if(ss.eof())
    {
        cout<< "Error: too few arguments" << endl;
        return;
    }
//    cout << "!" << endl;
    string name;
    bool valid_cmd = false;   
    ss >> name;
    
    if(ss.fail())//******************************************************
    {
        cout<< "Error: invalid argument" << endl;
        return;
    }
//    cout << "!!" << endl;
    if(in_typeList(name) || in_keyWordsList(name))
    {
        cout << "Error: invalid shape name" << endl;
        return;
    }
    if(find_shape(name) != -1)
    {
        cout << "Error: shape " << name << " exists" << endl;
        return;
    }
    if(ss.eof())
    {
        cout<< "Error: too few arguments" << endl;
//        cout<< "here1" << endl;
        return;
    }
//    cout<< "here2" << endl;
    string type;
    ss >> type;
    if(in_typeList(type))
    {
        valid_cmd = true;
    }
//    cout<< "here3" << endl;
    if(!valid_cmd)
    {
        cout << "Error: invalid shape type" << endl;
        return;
    }
    else
    {
        //cout<<"store shape value"<<endl;//////////////////////////
        int info[4];
        int length = sizeof(info) / sizeof(int);
        std::stringstream ss_copy(ss.str());
        string ss_str[3];
        ss_copy >> ss_str[0] >> ss_str[1] >> ss_str[2];
        
//        cout<< "here?" << endl;
        
        if(!check_info(ss_copy, 4, ss_str[0],type))
        {
            return;
        }
        ss >> info[0] >> info[1] >> info[2] >> info[3];
        if(tail == array_size)
        {
            cout << "Error: shape array is full"  << endl;
            return;
        }
        create_shape(name, type, info);
        //delete [] info;
    }
    
    
        
    return;
}





void checkInput_move(stringstream& ss)
{
    if(ss.eof())
    {
        cout<< "Error: too few arguments" << endl;
        return;
    }
    string name; 
    ss >> name;
    int length = 2;
    
    
    if(ss.fail())//******************************************************
    {
        cout<< "Error: invalid argument" << endl;
        return;
    }
    if(find_shape(name) == -1)
    {
        cout<< "Error: shape " << name << " not found" << endl;
        return ;
    }
    if(ss.eof())
    {
        cout<< "Error: too few arguments" << endl;
        return;
    }
    
    
    
    std::stringstream ss_copy(ss.str());
    string ss_str[2];
    ss_copy >> ss_str[0] >> ss_str[1];
    if(!check_info(ss_copy, length, ss_str[0], ss_str[0]))
    {
        return;
    }
    
    int info[2];
    ss >> info[0] >> info[1];
    shapesArray[find_shape(name)] -> setXlocation(info[0]);
    shapesArray[find_shape(name)] -> setYlocation(info[1]);
    
    cout<< "Moved " << name << " to " << info[0] << " " << info[1] << endl;
    return;
}

void checkInput_rotate(stringstream& ss)
{
    string name; 
    if(ss.eof())
    {
        cout<< "Error: too few arguments" << endl;
        return;
    }
    ss >> name;
    
    if(ss.fail())//******************************************************
    {
        cout<< "Error: invalid argument" << endl;
        return;
    }
    if(find_shape(name) == -1)
    {
        //cout<<"here"<<endl;
        cout<< "Error: shape " << name << " not found" << endl;
        return ;
    }
    
    if(ss.eof())
    {
        cout<< "Error: too few arguments" << endl;
        return;
    }
    
    
    
      
    int length = 1;
    std::stringstream ss_copy(ss.str());
    string ss_str[2];
    ss_copy >> ss_str[0] >> ss_str[1];
    if(!check_info(ss_copy, length, ss_str[0], ss_str[0]))
    {
        return;
    }
    
    int angle;
    ss >> angle;
    shapesArray[find_shape(name)] -> setRotate(angle);
    cout<< "Rotated " << name << " by " << angle << " degrees"<< endl;
}
void draw_shapes(string name, bool all)
{
    if(all)
    {
        cout<< "Drew all shapes" << endl;
        for(int i=0; i<tail; i++)
        {
            if(shapesArray[i] != NULL)
            {
                shapesArray[i]->draw();
            }
        }
    }
    else
    {
        if(find_shape(name) == -1)
        {
            cout<< "Error: shape " << name <<" not found" << endl;
            return;
        }
        else
        {
            int pos = find_shape(name);
            cout<< "Drew " <<shapesArray[pos]->getName() << ": " << shapesArray[pos]->getType() << " ";
            cout<< shapesArray[pos]->getXlocation() << " " << shapesArray[pos]->getYlocation() << " ";
            cout<< shapesArray[pos]->getXsize() << " " << shapesArray[pos]->getYsize() << " "<<endl;
        }
    }
}

void checkInput_draw(stringstream& ss)
{
    if(ss.eof())
    {
        cout<< "Error: too few arguments" << endl;
        return;
    }
    string name;
    ss >> name;
    
    if(ss.fail())//******************************************************
    {
        cout<< "Error: invalid argument" << endl;
        return;
    }
    if(name != "all" && (in_typeList(name) || in_keyWordsList(name)))
    {
        cout << "Error: invalid shape name" << endl;
        return;
    }
    if(name != "all" && find_shape(name) == -1)
    {
        cout<< "Error: shape " << name << " not found" << endl;
        return ;
    }
    if(!ss.eof())
    {
        cout<< "Error: too many arguments" << endl;
        return;
    }

    
    
    draw_shapes(name, name == "all");
    
}

void delete_shapes(string name, bool all)
{
    if(all)
    {
        //cout<< "Delete: all shapes" << endl;
        for(int i=0; i<tail; i++)
        {
            if(shapesArray[i] != NULL)
            {
                delete shapesArray[i];
                shapesArray[i] = NULL;
            }
        }
        cout << "Deleted: all shapes" << endl;
    }
    else
    {
        if(find_shape(name) == -1)
        {
            cout<< "Error: shape " << name <<" not found" << endl;
            return;
        }
        else
        {
            int pos = find_shape(name);
            delete shapesArray[pos];
            shapesArray[pos] = NULL;
            cout<< "Deleted shape " << name << endl;

        }
    }
}

void checkInput_delete(stringstream& ss)
{
    if(ss.eof())
    {
        cout<< "Error: too few arguments" << endl;
        return;
    }
    string name;
    ss >> name;
    //cout<< "?"<< endl;
    if(ss.fail())//******************************************************
    {
        cout<< "Error: invalid argument" << endl;
        return;
    }
    //cout<< "??"<< name << endl;
    if(name != "all" && (in_typeList(name) || in_keyWordsList(name)))
    {
        cout << "Error: invalid shape name" << endl;
        return;
    }
    if(name != "all" && find_shape(name) == -1)
    {
        cout<< "Error: shape " << name << " not found" << endl;
        return ;
    }
    if(!ss.eof())
    {
        cout<< "Error: too many arguments" << endl;
        return;
    }
    
    //cout<< "???"<< endl;
    delete_shapes(name, name == "all");
}
// ECE244 Student: you may want to add the prototype of
// helper functions you write here

int main() {

    string line;
    string command;
    
    cout << "> ";         // Prompt for input
    getline(cin, line);    // Get a line from standard input
//    cout << "start" << endl;
    while ( !cin.eof () ) {
        // Put the line in a linestream for parsing
        // Making a new sstream for each line so flags etc. are cleared
        stringstream lineStream (line);
        
        // Read from string stream into the command
        // The only way this can fail is if the eof is encountered
        lineStream >> command;

        // Check for the command and act accordingly
        // ECE244 Student: Insert your code here
        if(command == "maxShapes")
        {
            checkInput_DB(lineStream);
        }
        else if(command == "create")
        {
//            cout << "start create" << endl;//////////////////////////
            checkInput_create(lineStream);
        }
        else if(command == "move")
        {
            //cout << "start move" << endl;//////////////////////////
            checkInput_move(lineStream);
        }
        else if(command == "rotate")
        {
            //cout << "start rotate" << endl;//////////////////////////
            checkInput_rotate(lineStream);
        }
        else if(command == "draw")
        {
            //cout << "start draw" << endl;//////////////////////////
            checkInput_draw(lineStream);
        }
        else if(command == "delete")
        {
            //cout << "start delete" << endl;//////////////////////////
            checkInput_delete(lineStream);
        }
        else
        {
            cout<< "Error: invalid command" << endl;
        }
        
        
        
        
        // Once the command has been processed, prompt for the
        // next command
        cout << "> ";          // Prompt for input
        getline(cin, line);
        
    }  // End input loop until EOF.
    
    return 0;
}

