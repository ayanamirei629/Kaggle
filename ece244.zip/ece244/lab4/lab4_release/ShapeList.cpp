//
//  ShapeList.cpp
//  Lab4
//
//  Created by Tarek Abdelrahman on 2020-10-25.
//  Copyright © 2020 Tarek Abdelrahman.
//
//  Permission is hereby granted to use this code in ECE244 at
//  the University of Toronto. It is prohibited to distribute
//  this code, either publicly or to third parties.

//  ECE244 Student:
//  Write the implementation (and only the implementation) of the ShapeList class below
#include "ShapeList.h"

ShapeList::ShapeList()
{
    head = nullptr;
}

ShapeList::~ShapeList()
{
    ShapeNode* temp = head;
      while(head != nullptr){
          head = head->getNext();
          delete temp;
//          temp = nullptr;
          temp = head;
      }
}

ShapeNode* ShapeList::getHead() const
{
    return head;
}

void ShapeList::setHead(ShapeNode* ptr)
{
    head = ptr;
//    head->setNext(nullptr);
}

ShapeNode* ShapeList::find(string name) const
{
    ShapeNode* temp = head;
    while(temp != nullptr)
    {
        if(temp->getShape()->getName() == name)
        {
            return temp;
        }
        temp = temp->getNext();
    }
    return nullptr;
}

void ShapeList::insert(ShapeNode* s)
{
    s->setNext(nullptr);
    
    ShapeNode* temp = head;
    if(head == nullptr)
    {
        head = s;
    }
    else
    {
        while(temp->getNext() != nullptr)
        {
            temp = temp->getNext();
        }
        temp->setNext(s);
        temp->getNext()->setNext(nullptr);
    }
    return;
}

ShapeNode* ShapeList::remove(string name)
{
    if(head == nullptr)
    {
        return nullptr;
    }
    else if(head->getShape()->getName() == name)
    {
        ShapeNode* next = head;
        if(head->getNext() == nullptr) //only head
        {
            head = nullptr;
        }
        else
        {
            head = head->getNext();
        }
        return next;        //?????????
    }
    
    ShapeNode* temp = head;
    bool found = false;
    while(temp->getNext() != nullptr)
    {
        if(temp->getNext()->getShape()->getName() == name)
        {
            found = true;
            break;
        }
        temp = temp->getNext();
    }    
    if(found)
    {
        
        ShapeNode* next = temp->getNext()->getNext();
        ShapeNode* output = temp->getNext();
        
//        delete temp->getNext();
        temp->setNext(next);
//        cout<<"here:"<<output->getShape()->getName()<<endl;
        
        return output;
    }
    return nullptr;
}

void ShapeList::print() const
{
    ShapeNode* temp = head;
    while(temp != nullptr)
    {
        temp->print();
        temp = temp->getNext();
    }
    return;
}


