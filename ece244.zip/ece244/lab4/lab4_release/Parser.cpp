//
//  parser.cpp
//  Lab4
//
//  Created by Tarek Abdelrahman on 2020-10-25.
//  Copyright © 2020 Tarek Abdelrahman.
//
//  Permission is hereby granted to use this code in ECE244 at
//  the University of Toronto. It is prohibited to distribute
//  this code, either publicly or to third parties.


#include <iostream>
#include <sstream>
#include <string>

using namespace std;

#include "globals.h"
#include "Shape.h"
#include "ShapeNode.h"
#include "GroupNode.h"
#include "ShapeList.h"
#include "GroupList.h"

// This is a pointer to the groups list
// The list itseld must be allocated
GroupList* gList;


bool in_typeList(string l)
{
    for(int i=0; i < NUM_TYPES; i++)
    {
        if(shapeTypesList[i] == l)
        {
            return true;
        }
    }
    return false;
}

bool in_keyWordsList(string l)
{
    for(int i=0; i < NUM_KEYWORDS; i++)
    {
        if(keyWordsList[i] == l)
        {
            return true;
        }
    }
    return false;
}

int find_shape(string name)
{
    ShapeList* temp_shape;
    GroupNode* temp_group = gList->getHead();
    while(temp_group != nullptr)
    {
        temp_shape = temp_group->getShapeList();
        if(temp_shape->find(name) != nullptr)
        {
            return 1;
        }
        temp_group = temp_group->getNext();
    }
    return -1;
}

int find_group(string name)
{
    GroupNode* temp_group = gList->getHead();
    while(temp_group != nullptr)
    {
        if(temp_group->getName() == name)
        {
            return 1;
        }
        temp_group = temp_group->getNext();
    }
    return -1;
}

bool stringIsDigit(string s)
{
    std::string str(s);
//    cout <<str.size()<<endl;
    for(int i =0; i < str.size();i++)
    {           
        if(!isdigit(s[i]) && i != 0)
        {
            return false;
        }
        if(i == 0 and s[i] != '-' && !isdigit(s[i]))
        {
            return false;
        }
    }
    return true;
}


bool check_info(stringstream& ss, int length, string command, string type)
{
    string info[length];
//    string s_input[3];
//    ss >> s_input[0] >> s_input[1] >> s_input[2];
//    cout<<"ss: " << s_input[0] << s_input[1] << s_input[2] << endl;///////////////////////
//    cout<<"check"<< stringIsDigit(s_input[0])<< endl;
    int value;
    for(int i=0; i<length; i++)
    {    
        if(i < length - 1 && ss.eof())
        {
            //cout<< length - 1 << " " << ss.eof() << endl;////////////////////////////
            cout<< "error: too few arguments" << endl;
            return false;
        }
        ss >> info[i];
//        cout << info[i] << "-> info with i: "<< i << endl;////////////////////////        
        if(ss.fail() || ss.peek() == 46 || !stringIsDigit(info[i]))
        {
//            cout<< length - 1 << " " << ss.eof() << endl;////////////////////////////////////
            cout<< "error: invalid argument" << endl;
            return false;
        }
        std::stringstream ss_temp(info[i]);
        ss_temp >> value;
        if(value < 0 || (command == "rotate" && value > 360))
        {
            cout<< "error: invalid value" << endl;
            return false;
        } 
        if(i == length - 1 && type == "circle" && info[i] != info[i-1])
        {
            cout<< "error: invalid value" << endl;
            return false;
        }
        if(i == length - 1 && !ss.eof())
        {
            cout<< "error: too many arguments" << endl;
            return false;
        }
        if(i < length - 1 && ss.eof())
        {
//            cout<< i << " " << ss.eof() << endl;////////////////////////////
            cout<< "error: too few arguments" << endl;
            return false;
        }
    }
    return true;
}

void create_shape(string name, string type, int* info)
{
//    cout<< "here2" << endl;
    for(int i=0; i < sizeof(info)/ sizeof(int); i++)
    {
        if(info[i] < 0)
        {
            cout << "error: invalid value" << endl;
            return;
        }
    }
    //cout << info[2] << info[3] << endl;
    //cout << name << endl;
    if(type == "circle" && info[2] != info[3])
    {
        cout << "error: invalid value" << endl;
        return;
    }
    
    Shape* new_shape = new Shape(name, type, info[0], info[2], info[1], info[3]);
    ShapeNode* new_shapeNode = new ShapeNode;
    new_shapeNode->setShape(new_shape); 
    //cout<< "here1" << endl;
    gList->getHead()->getShapeList()->insert(new_shapeNode);
    
//    delete new_shape;
//    new_shape = nullptr;
//    delete new_shapeNode;
//    new_shapeNode=nullptr;
    
    cout << name << ": " << type << " " << info[0] << " " << info[1] << " ";
    cout << info[2] << " " << info[3] << endl;
    return;
}

void checkInput_shape(stringstream& ss)
{
    if(ss.eof())
    {
        cout<< "error: too few arguments" << endl;
        return;
    }
    string name;
    bool valid_cmd = false;   
    ss >> name;
    if(ss.fail())//******************************************************
    {
        cout<< "error: invalid argument" << endl;
        return;
    }
    if (in_typeList(name) || in_keyWordsList(name))
    {
        cout << "error: invalid name" << endl;
        return;
    }
    if(find_group(name) == 1 || find_shape(name) == 1)
    {
        cout << "error: name " << name << " exists" << endl;
        return;
    }
    //shape type
    if(ss.eof())
    {
        cout<< "error: too few arguments" << endl;
        return;
    }
    string type;
    ss >> type;
    if(in_typeList(type))
    {
        valid_cmd = true;
    }
    if(!valid_cmd)
    {
        cout << "error: invalid shape type" << endl;
        return;
    }
    else
    {
        //cout<<"store shape value"<<endl;//////////////////////////
        int info[4];
        int length = sizeof(info) / sizeof(int);
        std::stringstream ss_copy(ss.str());
        string ss_str[3];
        ss_copy >> ss_str[0] >> ss_str[1] >> ss_str[2];
        
        //cout<< "here?" << endl;
        
        if(!check_info(ss_copy, 4, ss_str[0],type))
        {
            return;
        }
        ss >> info[0] >> info[1] >> info[2] >> info[3];

        create_shape(name, type, info);
//        delete [] info;
    }
}

void move_shapeNode(string name, string group_name)
{
    GroupNode* temp_node = gList->getHead();
    ShapeList* temp_list;
    ShapeNode* temp_shape;
    bool found = false;
    
    while(!found && temp_node != nullptr)
    {
        temp_list = temp_node->getShapeList();
        temp_shape = temp_list->remove(name);
        if(temp_shape != nullptr)
        {
            found = true;
//            cout<<"found shape: "<< temp_shape->getShape()->getName() << endl;
            break;
        }
        temp_node = temp_node->getNext();
    }
//    cout<<"??"<<endl;
    temp_node = gList->getHead();
    while(temp_node != nullptr && temp_node->getName() != group_name)
    {
        temp_node = temp_node->getNext();
    }
//    cout << "here" << endl;
//    temp_shape->print();
    temp_node->getShapeList()->insert(temp_shape);
    
    return;
}

void checkInput_group(stringstream& ss)
{
    if(ss.eof())
    {
        cout<< "error: too few arguments" << endl;
        return;
    }
    string group_name; 
    ss >> group_name;
    
    
    if (in_typeList(group_name) || in_keyWordsList(group_name))
    {
        cout << "error: invalid name" << endl;
        return;
    }
    if(find_group(group_name) == 1 || find_shape(group_name) == 1)
    {
        cout << "error: group " << group_name << " exists" << endl;
        return;
    }
//    cout<<"1"<<endl; //------------------
    GroupNode* new_group = new GroupNode(group_name);
    gList->insert(new_group);
//    delete new_group;
    
    cout << group_name << ": group" << endl;
    
    return;
}

void checkInput_draw(stringstream& ss)
{
    if(!ss.eof())
    {
        cout<< "error: too many arguments" << endl;
        return;
    }
    
    gList->print();
    
    return;
}

void checkInput_move(stringstream& ss)
{
    if(ss.eof())
    {
        cout<< "error: too few arguments" << endl;
        return;
    }
    string name; 
    ss >> name;    
    
    if(ss.fail())//******************************************************
    {
        cout<< "error: invalid argument" << endl;
        return;
    }
    if(find_shape(name) == -1)
    {
        cout<< "error: shape " << name << " not found" << endl;
        return ;
    }
    if(ss.eof())
    {
        cout<< "error: too few arguments" << endl;
        return;
    }
    
//    std::stringstream ss_copy(ss.str());
    string group_name;
    ss >> group_name;
    if(find_group(group_name) == -1)
    {
        cout<< "error: group "<< group_name << " not found" << endl;
        return;
    }
    
    //move
    move_shapeNode(name,group_name);
    cout<< "moved " << name << " to "  << group_name << endl;
    return;
}

void delete_group(string name)
{
    GroupNode* removed = gList->remove(name);
//    removed->print();
//    gList->print();
    ShapeNode* transfer_node = removed->getShapeList()->getHead();
    removed->getShapeList()->setHead(nullptr);
    ShapeNode* next_node;
    
    if(transfer_node == nullptr)
    {
        
    }
    else if(transfer_node->getNext() == nullptr)
    {
        gList->getHead()->getShapeList()->insert(transfer_node);
    }
    else
    {
        while(transfer_node->getNext() != nullptr)
        {
            //cout<<"now transfer";
//            transfer_node->print();
            next_node = transfer_node->getNext();
            gList->getHead()->getShapeList()->insert(transfer_node);
            transfer_node = next_node;
        }
        gList->getHead()->getShapeList()->insert(transfer_node);
    }
    
    cout << removed->getName() << ": deleted" << endl;
    
    delete removed;
    removed = nullptr;
    return;
}

void delete_shape(string name)
{
    GroupNode* temp_node = gList->getHead();
    ShapeNode* temp_shapeNode;
    
    while(temp_node != nullptr)
    {
        temp_shapeNode = temp_node->getShapeList()->remove(name);
        if(temp_shapeNode != nullptr)
        {
            cout << temp_shapeNode->getShape()->getName() << ": deleted" << endl;
            delete temp_shapeNode;
            temp_shapeNode = nullptr;
            return ;
        }
        temp_node = temp_node->getNext();
    }
    return;
}

void checkInput_delete(stringstream& ss)
{
    if(ss.eof())
    {
        cout<< "error: too few arguments" << endl;
        return;
    }
    string name; 
    ss >> name;
    
    if (in_typeList(name) || in_keyWordsList(name))
    {
        cout << "error: invalid name" << endl;
        return;
    }
    
    if(find_group(name) == 1)
    {
        delete_group(name);
    }
    else if(find_shape(name) == 1)
    {
        delete_shape(name);
    }
    else
    {
        cout << "error: shape " << name << " not found" << endl;
        return;
    }
    
    return;
}

// ECE244 Student: you may want to add the prototype of
// helper functions you write here

int main() {
    // Create the groups list
    gList = new GroupList();

    // Create the poo group and add it to the group list
    GroupNode* poolGroup = new GroupNode(keyWordsList[NUM_KEYWORDS-1]);
    gList->insert(poolGroup);
 
    string line;
    string command;
    
    cout << "> ";         // Prompt for input
    getline(cin, line);    // Get a line from standard input

    while ( !cin.eof () ) {
        // Put the line in a linestream for parsing
        // Making a new sstream for each line so flags etc. are cleared
        stringstream lineStream (line);
        
        // Read from string stream into the command
        // The only way this can fail is if the eof is encountered
        lineStream >> command;

        // Check for the command and act accordingly
        // ECE244 Student: Insert your code here
        if(command == "shape")
        {
            checkInput_shape(lineStream);
        }
        else if(command == "group")
        {
//            cout << "start create" << endl;//////////////////////////
            checkInput_group(lineStream);
        }
        else if(command == "draw")
        {
//            cout << "start create" << endl;//////////////////////////
            checkInput_draw(lineStream);
        }
        else if(command == "move")
        {
//            cout << "start create" << endl;//////////////////////////
            checkInput_move(lineStream);
        }
        else if(command == "delete")
        {
//            cout << "start create" << endl;//////////////////////////
            checkInput_delete(lineStream);
        }
        else
        {
            cout<< "error: invalid command" << endl;
        }
        // Once the command has been processed, prompt for the
        // next command
        cout << "> ";          // Prompt for input
        getline(cin, line);
        
    }  // End input loop until EOF.
    
    return 0;
}

