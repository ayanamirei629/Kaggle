//
//  GroupList.cpp
//  Lab4
//
//  Created by Tarek Abdelrahman on 2020-10-25.
//  Copyright © 2020 Tarek Abdelrahman.
//
//  Permission is hereby granted to use this code in ECE244 at
//  the University of Toronto. It is prohibited to distribute
//  this code, either publicly or to third parties.

//  ECE244 Student:
//  Write the implementation (and only the implementation) of the GroupList class below

#include "GroupList.h"


GroupList::GroupList()
{
    head = nullptr;
}

GroupList::~GroupList()
{
    GroupNode* next = head;
    while(head != nullptr)
    {
        head = head->getNext();
        delete next;
        next = head;
    }
}


GroupNode* GroupList::getHead() const
{
    return head;
}

void GroupList::setHead(GroupNode* ptr)
{
    head = ptr;
    head->setNext(nullptr);
}
    
void GroupList::insert(GroupNode* s)
{
    GroupNode* next = head;
    if(next == nullptr)
    {
        head = s;
//        s->getNext()->print();
    }
    else
    {
        while(next->getNext() != nullptr)
        {
            next = next->getNext();
        }
//        cout<<"2"<<endl;
        next->setNext(s);
//        next->getNext()->setNext(nullptr);
    }
}

GroupNode* GroupList::remove(string name)
{
    GroupNode* temp = head;
    GroupNode* next;
    bool found = false;
      
    while(temp->getNext()!= nullptr)
    {
        if(temp->getNext()->getName() == name)
        {
            found = true;
            break;
        }
        temp = temp->getNext();
    }
//    temp->getNext()->print();
    if(found)
    {
        GroupNode* output = temp->getNext();  
        next = temp->getNext()->getNext();
        temp->setNext(next);
        output->setNext(nullptr);
        return output;
    } 
    return nullptr;
}

void GroupList::print() const
{
    GroupNode * temp = head;
    cout << "drawing:" << endl; 
    while(temp != nullptr)
    {
        cout << temp->getName() << ":" << endl;
        temp->getShapeList()->print();
        temp = temp->getNext();
    }
    
}