//
//  playMove.cpp
//  TicTacToe
//
//  Created by Tarek Abdelrahman on 2019-06-07.
//  Modified by Tarek Abdelrahman on 2020-09-17.
//  Copyright © 2019-2020 Tarek Abdelrahman. All rights reserved.
//
//  Permission is hereby granted to use this code in ECE244 at
//  the University of Toronto. It is prohibited to distribute
//  this code, either publicly or to third parties.
//
//  ECE244 Student: write your code for playMove in this file

#include "globals.h"
#include "GameState.h"
#include <iostream>
#include <string>
using namespace std;
void gameStatus(GameState& game_state)
{
    //get player
    int player;
    if(game_state.get_turn())
    {
        player = 1;
    }
    else
    {
        player = -1;
    }
    
    //check wincode 123
    int count = 0;
    for(int i = 0; i < boardSize; i++)
    {
        for(int j = 0; j < boardSize; j++)
        {
            if(game_state.get_gameBoard(i, j) == player)
            {
                count += 1;
            }
            else
            {
                count = 0;
                break;
            }
        }
        if(count == 3)
        {
            game_state.set_winCode(i + 1);
            game_state.set_gameOver(true);
            //return ;
        }
        count = 0;

    }
    
    //check wincode 456
    count = 0;
    for(int j = 0; j < boardSize; j++)
    {
        for(int i = 0; i < boardSize; i++)
        {
            if(game_state.get_gameBoard(i, j) == player)
            {
                count += 1;
                //cout << "current loc: row " << i << "col:" << j<< endl;
            }
            else
            {
                break;
            }
        }
        if(count == 3)
        {
            //cout << "current loc: " << "col:" << j<< endl;
            game_state.set_winCode(j + 4);
            game_state.set_gameOver(true);
            //return ;
        }
        count = 0;

    }

    //left -> right
    count = 0;
    for(int i = 0; i < boardSize; i++)
    {
        if(game_state.get_gameBoard(i, i) == player)
        {
            count += 1;
        }
        else
        {
            break;
        }
    }
    if(count == 3)
    {
        game_state.set_winCode(7);
        game_state.set_gameOver(true);
        //return ;
    }

    //(2,0) -> (0,2)
    count = 0;
    for(int i = 2, j = 0; i >= 0 && j < boardSize; i--, j++)
    {
        if(game_state.get_gameBoard(i, j) == player)
        {
            count += 1;
        }
        else
        {
            break;
        }
    }
    if(count == 3)
    {
        game_state.set_winCode(8);
        game_state.set_gameOver(true);
        //return ;
    }
    
    //check draw
    count = 0;
    for(int i = 0; i < boardSize; i++)
    {
        for(int j = 0; j < boardSize; j++)
        {
            if(game_state.get_gameBoard(i, j) == 0)
            {
                count += 1;
                break;
            }
        }
    }
    if(count == 0)
    {
        game_state.set_gameOver(true);
    }

    return ;
}


void playMove(GameState& game_state) 
{
    //validation of the move
    if(game_state.get_gameBoard(game_state.get_selectedRow(), game_state.get_selectedColumn()) != Empty)
    {
        game_state.set_moveValid(false);
        return ;
    }
    else
    {
        game_state.set_moveValid(true);
    }
    

    //The game board at the appropriate location by either X or O
    if(game_state.get_turn())
    {
        game_state.set_gameBoard(game_state.get_selectedRow(), game_state.get_selectedColumn(), 1);
    }
    else
    {
        game_state.set_gameBoard(game_state.get_selectedRow(), game_state.get_selectedColumn(), -1);
    }
    
    //check game status befor flip turn
    gameStatus(game_state);
    //The turn value to reflect that the turn has changed
    game_state.set_turn(!game_state.get_turn());
    
    
}

