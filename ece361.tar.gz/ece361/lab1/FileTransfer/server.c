#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

#define BUFFER_SIZE 1024

int main(int argc, char const *argv[])
{
    fprintf(stdout, "server -<UDP listen port>\n");
    if(argc!= 2)
    {
        exit(1);
    }
    
    int sockfd;	
    // open socket (DGRAM) Beej's page 75
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) 
    {
        perror("socket");
        exit(1);
    }

    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(atoi(argv[1]));
    server_address.sin_addr.s_addr = htonl(INADDR_ANY);	

    

    //bind the socket ,Beej page 37
    if (bind(sockfd, (struct sockaddr *)&server_address
            , sizeof(server_address)) == -1) 
    {
        perror("bind failed");
        exit(1);
    }
    


    char buffer[BUFFER_SIZE] = {0};
    struct sockaddr_in client_address; 
    socklen_t clilen = sizeof(client_address); 
    // recive message from client
    if (recvfrom(sockfd, buffer, BUFFER_SIZE, 0
            , (struct sockaddr *) &client_address, &clilen) == -1) 
    {
        perror("recvfrom error");
        exit(1);
    }

    // send message back after receiving
    if (strcmp(buffer, "ftp") == 0) 
    {
        sendto(sockfd, "yes", strlen("yes"), 0
                , (struct sockaddr *) &client_address, clilen);
    } 
    else 
    {
        sendto(sockfd, "no", strlen("no"), 0
                , (struct sockaddr *) &client_address, clilen);
    }
    
    printf("!!");
    close(sockfd);
    return 0;
}