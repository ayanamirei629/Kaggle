#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <netdb.h>
#include <unistd.h>
#include <ctype.h>
#include <time.h>

#define BUFFER_SIZE 1024

int main(int argc, char const *argv[])
{
    if (argc != 3) {
        fprintf(stderr, "deliver <server address> <server port number>\n");
        exit(0);
    }
    
    int port = atoi(argv[2]);
 
    int sockfd;	
    // open socket (DGRAM) Beej's page 75
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) 
    {
        perror("socket");
        exit(1);
    }
    
    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(atoi(argv[2]));
    server_address.sin_addr.s_addr = inet_addr(argv[1]);	
    
    char buffer[BUFFER_SIZE];
    char message[BUFFER_SIZE];
    
    //get user input
    printf("ftp ");
    scanf("%s", message);


    char filename[BUFFER_SIZE] = {0};

    printf("ftp ");
    scanf("%s", message);
    
    //check the file
    FILE *file;
    file = fopen(message, "r");
    if(file == NULL)
    {
        fprintf(stderr, "File %s not found\n", message);
        close(sockfd);
        exit(1);
    }

    fclose(file);
    
    int numbytes;
    // send the message
    sendto(sockfd, "ftp", strlen("ftp"), 0, (const struct sockaddr *)&server_address, sizeof(server_address));

    if((numbytes = recvfrom(sockfd, buffer, BUFFER_SIZE, 0
            , NULL, NULL)) == -1) 
    {
        fprintf(stderr, "recvfrom error");
        exit(1);
    }

    if(strcmp(buffer, "yes") == 0) 
    {
        fprintf(stdout, "A file transfer can start\n");
    }

    close(sockfd);
    
    return 0;
}