


#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include <stdbool.h> 
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <netdb.h>
#include <unistd.h>
#include <ctype.h>
#include <time.h>

#define BUFFER_SIZE 1000
#define DATA_SIZE 1100    

// struct for each individual packet to be sent
struct packet {
	unsigned int total_frag;
	unsigned int frag_no;	
	unsigned int size;
	char* filename;
	char filedata[1000];
	struct packet* next;
};

int main(int argc, char const *argv[])
{
    if (argc != 3) 
    {
        fprintf(stderr, "deliver <server address> <server port number>\n");
        exit(0);
    }
    
    int port = atoi(argv[2]);
 
    int sockfd;	
    sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    // open socket (DGRAM) Beej's page 75
    if (sockfd == -1) 
    {
        perror("socket");
        exit(1);
    }
    
    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    //port
    server_address.sin_port = htons(atoi(argv[2]));
    //ip
    server_address.sin_addr.s_addr = inet_addr(argv[1]);	
    
    char buffer[BUFFER_SIZE] = {0};
    char message[BUFFER_SIZE] = {0};
    
    //get user input
    printf("FTP ");
    scanf("%s", message);


    char filename[BUFFER_SIZE] = {0};
    //check the file
    FILE *file;
    printf("start open\n");
    file = fopen(message, "r");
    if(file == NULL)
    {
        fprintf(stderr, "File %s not found\n", message);
        close(sockfd);
        exit(1);
    }
    close(file);
 
    //start timer
    clock_t start_send, back;
    start_send = clock();
    // send the message
    sendto(sockfd, "ftp", strlen("ftp"), 0, (const struct sockaddr *)&server_address, sizeof(server_address));
    
    char res[BUFFER_SIZE];
    if((recvfrom(sockfd, res, BUFFER_SIZE, 0
            , NULL, NULL)) == -1) 
    {
        fprintf(stderr, "recvfrom error");
        exit(1);
    }
    back = clock();
    // get rtt time for the TCP
    double  rtt= (double) (back - start_send)*1000000 / CLOCKS_PER_SEC;
    printf("RTT: %.2f microsecond.\n",rtt);  

    if(strcmp(res, "yes") == 0) 
    {
        fprintf(stdout, "A file transfer can start\n");
    }
    else
    {
        printf("Not received\n");
    }
    //printf("1\n");
    //start transfer
	file = fopen(message, "rb");
	//printf("2\n");
    // calculate size of file
	fseek(file, 0, SEEK_END);
	int f_size = ftell(file);
	//printf("3\n");
	//back to begining
    fseek(file, 0, SEEK_SET);
    
    //calculate total packets
    int fragments = f_size/1000 + 1;
    //printf("fragments: %d, file size: %d",fragments,f_size);
    //printf("total fragments: %d\n", fragments);
    char packet_data[BUFFER_SIZE];
    
    struct packet *prev_p, *head_p, *cur_p;
    
    printf("start adding packets\n");
	//add packets
	for (int i = 1; i <= fragments; i++) 
	{
		
		// creates a new packet with respective memory allocation
		struct packet *temp_p = malloc(sizeof(struct packet));
		
		//set head packet
		if (i == 1) 
		{
			head_p = temp_p;
		}
		//else, set next packet
		else 
		{
			prev_p->next = temp_p;
		}
		
		// stores values
		temp_p->total_frag = fragments;
		temp_p->frag_no = i;
		//read in buffer and store size
		int n = fread(packet_data, 1, 1000, file);
		temp_p->size = n;
		temp_p->filename = message;
		//store in packet
		memcpy(temp_p->filedata, packet_data, n);
		//prepare for next packet
		temp_p->next = NULL;
		
		// Changes previous packet pointer to new packet
		prev_p = temp_p;
		printf("finish loop %d\n", i);
	}    
    
    fclose(file);

    
    double devRTT = rtt;
    double sRTT = rtt;
    double timeout = sRTT + 4*devRTT;
    
    
    //start from head packet and transfer
    cur_p = head_p;
    int total_len = 4;
    //while not til the end of packet, keep sending
    printf("start sending packets\n");
    while(cur_p != NULL)
    {
        //length of the packet
        total_len += snprintf(NULL, 0, "%d", cur_p->total_frag);
        total_len += snprintf(NULL, 0, "%d", cur_p->frag_no);
        total_len += snprintf(NULL, 0, "%d", cur_p->size);
        total_len += snprintf(NULL, 0, "%d", cur_p->filename);
        total_len += cur_p->size;
        printf("for packet %d of %d, total size %d, TOTAL: %d\n", cur_p->frag_no
            ,cur_p->total_frag, cur_p->size, total_len);
        
        //melloc for sending
        char* pack_send = malloc(total_len * sizeof(char));
        
        //fills string
		int pac = sprintf(pack_send, "%d:%d:%d:%s:"
		                , cur_p->total_frag, cur_p->frag_no
		                , cur_p->size, cur_p->filename);
		                
		//copy the data into the string starting from the index calculated above
		memcpy(&pack_send[pac], cur_p->filedata, cur_p->size);		
		//printf("send packet: %s\n", pack_send);
		//send packet
		int sent_packet = sendto(sockfd, pack_send, total_len, 0
		            , (const struct sockaddr *)&server_address
		            , sizeof(server_address));
		//if (sent_packet == -1) 
		//{
			//printf("fail to send'\n");
			//return 0;	
		//}	
		//else
		//{
		    //printf("send successful for frag number: %d\n", cur_p->frag_no);
		//}
		printf("hang on, wait receiving...\n");
		
		
		clock_t send_start = clock();
		int cur_start = send_start;
		int send_count = 1;
		bool tout =  false;
		bool keep_send = true;
		
		while(keep_send)
		{
		    //printf("!!!!!!\n");
		    clock_t cur_t = clock();
		    // time out
		    if((double) (cur_t - cur_start)*1000000 / CLOCKS_PER_SEC > timeout)
		    {   
		        printf("???????????\n");
		        //send count += 1
		        send_count += 1;
		        // 10 failure,execute programme
		        if(send_count == 11)
		        {
		            printf("sending failures reach the threshold. End Programme\n");
		            return 0;
		        }
		        else
		        {
		            printf("sending packet for attempts: %d\n", send_count);
            		int sent_packet = sendto(sockfd, pack_send, total_len, 0
		                    , (const struct sockaddr *)&server_address
		                    , sizeof(server_address));
		            
	            }
        		if (sent_packet == -1) 
	            {
		            printf("fail to send'\n");
		            return 0;	
	            }	
	            else
	            {
	                printf("send successful for frag number: %d, attampts: %d\n", cur_p->frag_no, send_count);
	            }
	            //printf("wait receiving...\n");
	            //reset the timer
	            cur_start = cur_t;

		    }
		    //within the time, keep waiting for receiving
		    else
		    {
    		    //check receive
		        printf("start %s\n",res);		                    
		        socklen_t addrlen = sizeof(server_address);
		        int receive_output = recvfrom(sockfd, res, BUFFER_SIZE , 0
		                            ,(const struct sockaddr *)&server_address
		                            , &addrlen);
		        //printf("received: %s, return: %d\n", res,receive_output);
		        if (receive_output == -1) 
		        {
			        printf("Error in receiving %s\n", res);
			        return 0;
		        }		
		        if(strcmp(res, "ACK") == 0)
		        {
		            printf("ACK succeed on attempt: %d\n", send_count);
		            keep_send = false;
		            clock_t finish_time = clock();
		            // update RTT time for next round
		            sRTT = 0.8 * sRTT +  0.2 * ((finish_time - send_start)*1000000 / CLOCKS_PER_SEC);
		            devRTT = 0.8 * devRTT + 0.2 * fabs(sRTT - (cur_t - send_start)*1000000 / CLOCKS_PER_SEC);
		            //devRTT = sRTT;
		            timeout = sRTT + 4*devRTT;
		            //printf("estimated timout: %.2f microsecond.\n",timeout);
		            //printf("DEV: %.2f microsecond. sRTT: %.2f microsecond.\n",devRTT, sRTT);
		            break;
		        }
		        else
		        {
		            printf("Not ACK\n");
		        }
		    
		    }    
		    
		}
		
		//send next packet
		cur_p = cur_p->next;
		//free memory
		free(pack_send);
		total_len = 4;
    }
    
    printf("RTT: %.2f microsecond.\n",rtt); 
    close(sockfd);
    
    return 0;
}

