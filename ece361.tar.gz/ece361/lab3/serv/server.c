#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdbool.h>
#define BUFFER_SIZE 1100
#define DATA_SIZE 1100    
// Struct for each individual packet to be sent
struct packet {
	unsigned int total_frag;
	unsigned int frag_no;	
	unsigned int size;
	char* filename;
	char filedata[1000];
	struct packet* next;
};

int main(int argc, char const *argv[])
{
    fprintf(stdout, "server <UDP listen port>\n");
    if(argc!= 2)
    {
        exit(1);
    }
    
    int sockfd;	
    // open socket (DGRAM) Beej's page 75
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) 
    {
        perror("socket");
        exit(1);
    }

    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    //port
    server_address.sin_port = htons(atoi(argv[1]));
    server_address.sin_addr.s_addr = htonl(INADDR_ANY);	

    

    //bind the socket ,Beej page 37
    if (bind(sockfd, (struct sockaddr *)&server_address
            , sizeof(server_address)) == -1) 
    {
        perror("bind failed");
        exit(1);
    }


    char buffer[BUFFER_SIZE] = {0};
    struct sockaddr_in client_address; 
    socklen_t clilen = sizeof(client_address); 
    // recive message from client
    if (recvfrom(sockfd, buffer, BUFFER_SIZE, 0
            , (struct sockaddr *) &client_address, &clilen) == -1) 
    {
        perror("recvfrom error");
        exit(1);
    }

    // send message back after receiving
    if (strcmp(buffer, "ftp") == 0) 
    {
        printf("correct!\n");
        sendto(sockfd, "yes", strlen("yes"), 0
                , (struct sockaddr *) &client_address, clilen);
    } 
    else 
    {
//        printf("false %s!\n", buffer);
        sendto(sockfd, "no", strlen("no"), 0
                , (struct sockaddr *) &client_address, clilen);
        exit(1);
    }
    
    //initialize file to write
	FILE * file;
	char data[DATA_SIZE];
	bool done = false;
    
    while(!done)
    {
        //get income packets
        int temp = recvfrom(sockfd, data, 1100, 0
                        ,&client_address, &clilen);
		if (temp == -1) 
		{
			printf("Error in receiving the packet in server\n");
			return 0;
		}
		else
		{
		    printf("received successfully\n");
		}
		
		//******************************
		//start with random drop
		//send back ACK
		//if (true) 
		if (rand() % 100 > 5) 
		{
		    printf("passed this time\n");
		    int ack = sendto(sockfd, "ACK", strlen("ACK"), 0,(struct sockaddr *)  &client_address, clilen);
		    if (ack == -1) 
		    {
			    printf("Error in sending ack\n");
			    return 0;
		    }
            //printf("receiving data: %s\n",data);
		    //convert packet 
		    char * total_frags = strtok(data, ":"); 
		    char * frag_nos = strtok(NULL, ":");
		    char * sizes = strtok(NULL, ":");
		    char * file_name = strtok(NULL, ":");		
		    //get position of string values
		    int total_frag_final = atoi(total_frags);
		    int frag_num_final = atoi(frag_nos);
		    int size_final = atoi(sizes);		
            
		    //get copy start pos
		    int copy_pos = 4 + strlen(total_frags) + strlen(frag_nos) + strlen(sizes) + strlen(file_name);
		    char* pac_data = malloc(size_final * sizeof(char));
	        //get data
		    memcpy(pac_data, &data[copy_pos], size_final);
		    
		    //create packet 
		    struct packet *temp_p = malloc(sizeof(struct packet));
		    temp_p->total_frag = total_frag_final;
		    temp_p->frag_no = frag_num_final;
		    temp_p->size = size_final;
		    temp_p->filename = file_name;
		    memcpy(temp_p->filedata, pac_data, size_final);
		    printf("**************************************\n");
            //printf("total_frags : %d of %d\n", frag_num_final,total_frag_final);
            printf("frag_num_final : %d\n",frag_num_final);
            //printf("size_final : %d\n",size_final);
            //printf("file_name : %s\n",file_name);
            //printf("pac_data : %s\n",pac_data);
            printf("**************************************\n");
		    //open file when first frag
		    if (frag_num_final == 1) 
		    {
		        printf("create the file %s\n",file_name);
			    file = fopen(file_name, "wb");
		    }	
				    
		    if(frag_num_final == total_frag_final)
		    {
		        printf("last file, end iteration\n");
		        done = true;
		    }
	    
		    //write data
		    fwrite(temp_p->filedata, 1, size_final, file);
		    
		    //free packets
		    free(temp_p);
	    }
	    else{printf("dont send ACK\n");}
		//******************************
		//end with random drop
		
    }
    fclose(file);
    close(sockfd);
    
//    printf("end!\n");
    close(sockfd);
    return 0;
}
