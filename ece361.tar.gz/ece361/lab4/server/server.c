#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>
struct message 
{
	unsigned int type;
	unsigned int size;
	unsigned char source[1000];
	unsigned char data[1000];
};

typedef enum message_type 
{
	LOGIN,
	LO_ACK,
	LO_NAK,
	EXIT,
	JN_ACK,
	JN_NAK,
	LEAVE_SESS,
	NEW_SESS,
	NS_ACK,
	NS_NAK,
	MESSAGE,
	QUERY,
	QU_ACK,
	LOGOUT
}Message_type;



typedef struct user_info 
{
	char id[1000];
	char password[1000];
	bool live;
	char *sessionID[10];
	int source;
	time_t lastActivityTime;
}USER_INFO;

USER_INFO listOfUsers[3];



int main(int argc, char *argv[])
{
	bool loggedIn = false;
    fd_set readfds;
	// checks for 2 arguments being passed in <server> <port #>
	if (argc != 2) 
	{
		fprintf(stderr, "usage: server <server port number>\n");
		return 0;
	}
	
	// creation of the user list
	strcpy(listOfUsers[0].id, "craig");
	strcpy(listOfUsers[1].id, "carl");
	strcpy(listOfUsers[2].id, "zhuoran");


	strcpy(listOfUsers[0].password, "0000");
	strcpy(listOfUsers[1].password, "1111");
	strcpy(listOfUsers[2].password, "2222");

	
	listOfUsers[0].live = false;
	listOfUsers[1].live = false;
	listOfUsers[2].live = false;
	listOfUsers[0].source = -1;
	listOfUsers[1].source = -1;
	listOfUsers[2].source = -1;
	
	for(int i = 0;i<10;i++)
	{
        listOfUsers[0].sessionID[i] = NULL;
	    listOfUsers[1].sessionID[i] = NULL;
	    listOfUsers[2].sessionID[i] = NULL;
	}
    listOfUsers[0].lastActivityTime =(time_t)-1;
    listOfUsers[1].lastActivityTime =(time_t)-1;
	listOfUsers[2].lastActivityTime =(time_t)-1;
	char *sessionsList[3];
	for (int i = 0; i < 3; i++) 
	{
		sessionsList[i] = NULL;
	}
	
	
	
	
	
	// stores arguments passed in to variables
	char* server_string = argv[0];
	char* port_num = argv[1];
	
	// makes a  TCP socket
	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd == -1) 
	{
		printf("Error in making socket\n");
		return 0;
	}
	
	// sets parameters for the connection
	struct sockaddr_in connecting_address;
	connecting_address.sin_family = AF_INET;
	connecting_address.sin_addr.s_addr = INADDR_ANY;
	connecting_address.sin_port = htons(atoi(port_num));
	
	// binds the socket with the respective IP address and port #
	int bind_info = bind(sockfd, (struct sockaddr *)&connecting_address, sizeof(connecting_address));
	if (bind_info == -1) 
	{
		printf("Error in binding\n");
		return 0;
	}
	
	// listens repeatedly as long as server is open
	while (1) 
	{

		// listens for packet from client
	int l = listen(sockfd, 5);
		if (l == -1) 
		{
			printf("chopped listing");
		}	printf("listening: \n");
		
		
		// accepts the packet from the client
		int clientLen = sizeof(struct sockaddr_in);
		struct sockaddr_in cl;		
		printf("current sockfd: %d\n", sockfd);
		int sock = accept(sockfd, (struct sockaddr *)&cl, (socklen_t*)&clientLen);

		printf("Received sock: %d\n", sock);
		if (sock == -1) 
		{
			printf("Error in accepting\n");
			return 0;
		}
		
	    //CHECK TIMER
	    time_t currentTime = time(NULL);
		for(int i =0;i<3;i++)
		{
		    if(listOfUsers[i].live && difftime(currentTime, listOfUsers[i].lastActivityTime) > 120)
		    {
		        printf("More than 2 minutes of inactivity for user: %s.\nDisconnect.\n", listOfUsers[i].id);
		        listOfUsers[i].live = false;
		        listOfUsers[i].lastActivityTime = (time_t)-1;
		        for(int j=0; j <10; j++)
		        {
		            listOfUsers[i].sessionID[j] = NULL;
		        }
		        listOfUsers[i].source = -1;
		    }
		}
		printf("accepted packet, proceeding: \n");
		
		// initializes structs and variables for the messages
		struct message client;
		struct message server;
		char *type;
		char data[1000];
		
		// stores the data read in from the socket to data
		read(sock, data, 1000);

		// sets ptr to the first word of the command and stores it to typeS
		char *ptr = strtok(data, ":");
		type = malloc(sizeof(char) * (strlen(ptr)+1));
		strcpy(type, ptr);
		printf("here is the command: %s\n", ptr);
		// fills the rest of the client message struct excluding data
		client.type = atoi(ptr);
		ptr = strtok(NULL, ":");
		client.size = atoi(ptr);
		ptr = strtok(NULL, ":");
		strcpy(client.source, ptr);
		if (strcmp(type, "MESSAGE") == 0) 
		{
			// detects the rest of the message to get the data
			char *msg;
			ptr = strtok(NULL, "\0");
			msg = malloc(sizeof(char) * (strlen(ptr)+1));
			strcpy(msg, ptr);
		    bool logged_out = false;
		    

            //printf("id: %d\n", client.source);
            //char* senderSessionID = NULL;
            

            for (int i = 0; i < 3; i++) 
            {
                if (strcmp(listOfUsers[i].id, client.source) == 0) 
                {
                    if(listOfUsers[i].live == false)
                    {
                        logged_out = true;
                        break;
                    }
                    else
                    {
                        listOfUsers[i].lastActivityTime = time(NULL);
                    }
                    printf("Session: \n");
                    for(int j = 0; j < 10; j++) 
                    {
                        if(listOfUsers[i].sessionID[j] != NULL)
                        {
                            printf("%s",listOfUsers[i].sessionID[j]);
                            //loop to find every user in the session
                            for (int k = 0; k < 3; k++)
                            {
                                if(listOfUsers[k].live)
                                {
                                    printf("cur id: %s\n",listOfUsers[k].id);
                                    for (int l = 0; l < 10; l++)
                                    {
                                        if(listOfUsers[k].sessionID[l] != NULL)
                                        {
                                            printf("cur sess: %s\n",listOfUsers[k].sessionID[l]);
                                        }
                                    //same session
                                        if(listOfUsers[k].sessionID[l] != NULL && strcmp(listOfUsers[k].sessionID[l],listOfUsers[i].sessionID[j]) == 0)
                                        {
                                            char* packet_to_send = malloc(1000*sizeof(char));
                                            //print message
                        					server.type = NS_ACK;
				                            strcpy(server.data, "Session: ");
				                            strcpy(server.data, listOfUsers[i].sessionID[j]);
				                            strcpy(server.data, " msg: ");
				                            strcpy(server.data, msg);
				                            strcpy(server.source, listOfUsers[i].id);
				                            int data_string_size = strlen(server.data);
				                            int packet_members = sprintf(packet_to_send, "MSG_ACK:%d:%s:%s", data_string_size, server.source, msg);
				                            packet_to_send[packet_members+1] = '\0';
	                            			// sets size of the server message
			                                server.size = 1000;
			                                printf("Cur sock: %d ",sock);
			                                printf("Cur id sock: %d\n",listOfUsers[k].source);
			                                // writes the data to the socket for the client to read
			                                write(listOfUsers[k].source, packet_to_send, 1000);
			                                //write(sock, packet_to_send, 1000);
			
			                                // frees the stored data for the next iteration
			                                free(packet_to_send);
			                                printf("send back to user: %s\n", listOfUsers[k].id);
                                        }
                                    }
                                }
                            }
                            
                            
                            
                        }
                    }
                    break;
                }
            }
            if(!logged_out)
            {
                printf("\nHere is the message: %s",msg);           
            }
            else
            {
 			    char* packet_to_send = malloc(1000*sizeof(char)); 
			    server.type = NS_NAK;
				strcpy(server.data, "User logged out. Please login again...\n");
				strcpy(server.source, client.source);
				int data_string_size = strlen(server.data);
				int packet_members = sprintf(packet_to_send, "NS_NAK:%d:%s:%s", data_string_size, server.source, server.data);
				packet_to_send[packet_members+1] = '\0';	   
				write(sock, packet_to_send, 1000); 
				free(packet_to_send);          
            }
	        free(msg); 

		}
		// if the client message is a LOGIN message, then...
		if (strcmp(type, "LOGIN") == 0) 
		{
		    printf("login start! \n");
			if (loggedIn == true) 
			{
				printf("We already have a logged in user\n");
			}
			// goes through the rest of the command line and extracts information
			int count = 1;
			char *id, *pw;
			
			// goes to the first word after login
			ptr = strtok(NULL, ",");

			// traverses through the rest of the message and extracts information
			while (ptr != NULL) 
			{ 		
				// extracts the id of the user
				if (count == 1) 
				{ 
					id = malloc(sizeof(char) * (strlen(ptr)+1));
					strcpy(id, ptr);
					ptr = strtok(NULL, "\0");
					count++;
				}
				
				// extracts password of the user
				else if (count == 2) 
				{ 
					pw = malloc(sizeof(char) * (strlen(ptr)+1));
					strcpy(pw, ptr);
					break;
				}
			}
			
			// sets default flags
			bool foundUser = false;
			bool correctPass = false;
			bool newLogin = false;
			
			// checks to see if given user and pw can sign in or not
			for (int i = 0; i < 3; i++) 
			{
				if (strcmp(id, listOfUsers[i].id) == 0) 
				{
					foundUser = true;
					if (strcmp(pw, listOfUsers[i].password) == 0) 
					{
						correctPass = true;
						if (listOfUsers[i].live == false) 
						{
							listOfUsers[i].live = true;
							newLogin = true;
							listOfUsers[i].lastActivityTime = time(NULL);
						    listOfUsers[i].source = sock;
					    	//bind socket
					    	struct sockaddr_in connecting_address;
	                        connecting_address.sin_family = AF_INET;
	                        connecting_address.sin_addr.s_addr = INADDR_ANY;
	                        connecting_address.sin_port = htons(atoi(port_num));
	
	                        // binds the socket with the respective IP address and port #
	                        int bind_info = bind(sockfd, (struct sockaddr *)&connecting_address, sizeof(connecting_address));
						}
					}
				}
			}
			
			// creates memory for the string packet that needs to be sent
			char* packet_to_send = malloc(1000*sizeof(char));
		
			// creates packet with ACK or NAK depending on if the right information was given
			if (foundUser == true) 
			{
				if (correctPass == true) 
				{
					// send ACK for a successful log in
					if (newLogin == true) 
					{
						server.type = LO_ACK;
						strcpy(server.data, "Logged In");
						strcpy(server.source, client.source);
						int data_string_size = strlen(server.data);
						int packet_members = sprintf(packet_to_send, "LO_ACK: %d: %s: %s", data_string_size, server.source, server.data);
						packet_to_send[packet_members+1] = '\0';
						loggedIn = true;
					}
					// sends NAK if the user has already signed in previously
					else 
					{
						server.type = LO_NAK;
						strcpy(server.data, "Already signed in:");
						strcpy(server.source, client.source);
						int data_string_size = strlen(server.data);
						int packet_members = sprintf(packet_to_send, "LO_NAK: %d: %s: %s", data_string_size, server.source, server.data);
						packet_to_send[packet_members+1] = '\0';
					}
				}
				
				// sends NAK if valid user inputted incorrect password
				else 
				{
					server.type = LO_NAK;
					strcpy(server.data, "User found. Incorrect Password. Try again: ");
					strcpy(server.source, client.source);
					int data_string_size = strlen(server.data);
					int packet_members = sprintf(packet_to_send, "LO_NAK: %d: %s: %s", data_string_size, server.source, server.data);
					packet_to_send[packet_members+1] = '\0';
				}
				//
			}
			
			// sends NAK if given username does not exist
			else 
			{
				server.type = LO_NAK;
				strcpy(server.data, "User not found. Try again: ");
				strcpy(server.source, client.source);
				int data_string_size = strlen(server.data);
				int packet_members = sprintf(packet_to_send, "LO_NAK: %d: %s: %s", data_string_size, server.source, server.data);
				packet_to_send[packet_members+1] = '\0';
			}
			
			// sets size of the server message
			server.size = 1000;
			
			// writes the data to the socket for the client to read
			printf("current socket: %d\n", sock);
			write(sock, packet_to_send, 1000);
			
			// frees the stored data for the next iteration
			free(packet_to_send);
		}
		
		// if the client message is a QUIT message, then...
		else if (strcmp(type, "QUIT") == 0) 
		{
			// detects the rest of the message to get the data
			ptr = strtok(NULL, "\0");
			strcpy(client.data, ptr);
			
			// attemps to close the server
			printf("Attempting to quit: \n");
			close(sockfd);
			printf("Successfully closed\n");
			return 0;
		}
		
		else if (strcmp(type, "NEW_SESS") == 0) 
		{
			bool logged_out = false;
			// detects the rest of the message to get the data
			char *sessionID;
			ptr = strtok(NULL, "\0");
			sessionID = malloc(sizeof(char) * (strlen(ptr)+1));
			strcpy(sessionID, ptr);
			
			// checks if the session exists already
			bool found = false;
			bool created = false;
			for (int i = 0; i < 3; i++) 
			{
				if (sessionsList[i] != NULL) 
				{
					if (strcmp(sessionsList[i], sessionID) == 0)
					found = true;
				}
			}
			for (int i = 0; i < 3; i++) 
			{
				if (strcmp(listOfUsers[i].id, client.source) == 0) 
				{
				    if(listOfUsers[i].live == false)
				    {
				        printf("user logged out, cannot create session\n");
				        logged_out = true;
				        break;
				    }
				    else
				    {
				        listOfUsers[i].lastActivityTime = time(NULL);
				    }
			    }
			}
			// create new session if not found and if there is space for a new session
			if (found == false && !logged_out) 
			{
				for (int i = 0; i < 3; i++) 
				{
					if (sessionsList[i] == NULL) 
					{
						sessionsList[i] = malloc(sizeof(char) * (strlen(ptr)+1));
						strcpy(sessionsList[i], sessionID);
						created = true;
						break;
					}
				}
			}
			
			// creates memory for the string packet that needs to be sent
			char* packet_to_send = malloc(1000*sizeof(char));
			
			if (found == false) 
			{
			    if(logged_out)
			    {
					server.type = NS_NAK;
					strcpy(server.data, "User logged out. Please login again...\n");
					strcpy(server.source, client.source);
					int data_string_size = strlen(server.data);
					int packet_members = sprintf(packet_to_send, "NS_NAK:%d:%s:%s", data_string_size, server.source, server.data);
					packet_to_send[packet_members+1] = '\0';			    
			    }
				else if (created == true) 
				{
					server.type = NS_ACK;
					strcpy(server.data, sessionID);
					strcpy(server.source, client.source);
					int data_string_size = strlen(server.data);
					int packet_members = sprintf(packet_to_send, "NS_ACK:%d:%s:%s", data_string_size, server.source, sessionID);
					packet_to_send[packet_members+1] = '\0';
				}
				else 
				{
					server.type = NS_NAK;
					strcpy(server.data, "There are not enough rooms available for the new session. Please try again:");
					strcpy(server.source, client.source);
					int data_string_size = strlen(server.data);
					int packet_members = sprintf(packet_to_send, "NS_NAK:%d:%s:%s", data_string_size, server.source, server.data);
					packet_to_send[packet_members+1] = '\0';
				}
			}
			else 
			{
				server.type = NS_NAK;
				strcpy(server.data, "A session already exists with the same name. Please try again: ");
				strcpy(server.source, client.source);
				int data_string_size = strlen(server.data);
				int packet_members = sprintf(packet_to_send, "NS_NAK:%d:%s:%s", data_string_size, server.source, server.data);
				packet_to_send[packet_members+1] = '\0';
			}
			
			// sets size of the server message
			server.size = 1000;
			
			// writes the data to the socket for the client to read
			write(sock, packet_to_send, 1000);
			
			// frees the stored data for the next iteration
			free(packet_to_send);
		}
		
		
		else if (strcmp(type, "JOIN") == 0) 
		{
			// detects the rest of the message to get the data
			char *sessionID_joined;
			ptr = strtok(NULL, "\0");
			sessionID_joined = malloc(sizeof(char) * (strlen(ptr)+1));
			strcpy(sessionID_joined, ptr);
			
			// Create boolean to check if a session is joinable or not
			bool joinable = false;
            bool logged_out = false;
			// Go through list of sessions and check if the joined session exists
			for (int i = 0; i < 3; i++) 
			{
				if (sessionsList[i] != NULL) {				
					if (strcmp(sessionsList[i], sessionID_joined) == 0) 
					{
						joinable = true;
					
						for (int j = 0; j < 3; j++) 
						{
							if (listOfUsers[j].id != NULL) 
							{
								if (strcmp(listOfUsers[j].id, client.source) == 0) 
								{
								    if(listOfUsers[j].live == false)
								    {
								        printf("user logged out, cannot join\n");
								        logged_out = true;
								        break;
								    }
				                    else
				                    {
				                        listOfUsers[j].lastActivityTime = time(NULL);
				                    }
				                    
								    for(int k =0;k<10;k++)
								    {
								        if(listOfUsers[j].sessionID[k] == NULL)
								        {
								            listOfUsers[j].sessionID[k] = malloc(sizeof(char) * (strlen(sessionID_joined) + 1));
								            strcpy(listOfUsers[j].sessionID[k], sessionID_joined);
								            break;
								        }
								    }
									//listOfUsers[j].sessionID = malloc(sizeof(char) * (strlen(sessionID_joined)+1));
									//strcpy(listOfUsers[j].sessionID, sessionID_joined);
									printf("stores %s into SESSION: %s\n", listOfUsers[j].id, sessionID_joined);
									break;
								}
							}
						}
					}
				}
			}
						
			// creates memory for the string packet that needs to be sent
			char* packet_to_send = malloc(1000*sizeof(char));
			
			// If the session can be joined
			if (joinable == true && !logged_out) 
			{
				server.type = JN_ACK;
				strcpy(server.source, client.source);
				int data_string_size = strlen(server.data);
				int packet_members = sprintf(packet_to_send, "JN_ACK:%d:%s:%s", data_string_size, server.source, sessionID_joined);
				packet_to_send[packet_members+1] = '\0';
			}
			else if(logged_out)
			{
				server.type = JN_NAK;
				strcpy(server.data, "User logged out, please login again.");
				strcpy(server.source, client.source);
				int data_string_size = strlen(server.data);
				int packet_members = sprintf(packet_to_send, "JN_NAK:%d:%s:%s", data_string_size, server.source, server.data);
				packet_to_send[packet_members+1] = '\0';			    
			}
			// If the session cannot be joined
			else 
			{
				server.type = JN_NAK;
				strcpy(server.data, "The session has not been created yet. Please try again: ");
				strcpy(server.source, client.source);
				int data_string_size = strlen(server.data);
				int packet_members = sprintf(packet_to_send, "JN_NAK:%d:%s:%s", data_string_size, server.source, server.data);
				packet_to_send[packet_members+1] = '\0';
			}
		
			
			// sets size of the server message
			server.size = 1000;
			
			// writes the data to the socket for the client to read
			write(sock, packet_to_send, 1000);
			
			// frees the stored data for the next iteration
			free(packet_to_send);
		}
		
		// if the client message is a LIST message, then...
		else if (strcmp(type, "LIST") == 0) 
		{
		
			// creates memory for the string packet that needs to be sent and temp list string
			char* packet_to_send = malloc(1000*sizeof(char));
			char* creation_of_list = malloc(1000 *sizeof(char));
			
			strcat(creation_of_list, "List of available sessions: \n");
			
			for (int i = 0; i < 3; i++) 
			{
				if (sessionsList[i] != NULL) 
				{	
					char info[100];
					
					sprintf(info, "%s", sessionsList[i]);
					
					// attach to the list string
					strcat(creation_of_list, info);
				}
			}
			
			strcat(creation_of_list, "Here are the users online: \n");
			
			// goes through list of users to see who has logged in
			for (int i = 0; i < 3; i++) 
			{
				if (listOfUsers[i].live == true) 
				{
					strcat(creation_of_list, listOfUsers[i].id);
					strcat(creation_of_list, ": \n");
					// display session number for each logged in user, unless they are not in any sessions
					if (listOfUsers[i].sessionID[0] == NULL) 
					{
						strcat(creation_of_list, "    Not in Any Session\n");
					}
					else 
					{
						//printf(info, "%s: In session: ", listOfUsers[i].id);
						for(int j=0;j<10;j++)
						{
						    if(listOfUsers[i].sessionID[j] != NULL)
						    {
						        strcat(creation_of_list, listOfUsers[i].sessionID[j]);
						        //strcat(creation_of_list, " ");
						    }
						    else
						    {
						        break;
						    }
						    
						}
					}
					
				}
			}
			
			// fills out the packet to be sent with the necessary information
			int packet_members = sprintf(packet_to_send, "QU_ACK:%d:%s:%s", strlen(creation_of_list), client.source, creation_of_list);
			packet_to_send[packet_members+1] = '\0';
			
			// updates server message information
			server.type = QU_ACK;
			server.size = strlen(creation_of_list);
			strcpy(server.source, client.source);
			strcpy(server.data, packet_to_send);
			
			// writes the data to the socket for the client to read
			write(sock, packet_to_send, 1000);
			
			// frees the stored data for the next iteration
			free(packet_to_send);
			free(creation_of_list);
		}
		
		
		else if (strcmp(type, "LOGOUT") == 0) 
		{	
			// detects the rest of the message to get the data
			char *currentUser;
			ptr = strtok(NULL, "\0");
			currentUser = malloc(sizeof(char) * (strlen(ptr)+1));
			strcpy(currentUser, ptr);
			
			bool signedOut = false;
			for (int i = 0; i < 3; i++) 
			{
				if (listOfUsers[i].id != NULL) 
				{
					if (strcmp(listOfUsers[i].id, currentUser) == 0) 
					{
						listOfUsers[i].live = false;
						for(int j =0;j<10;j++)
						{
						    listOfUsers[i].sessionID[j] = NULL;
						}
						signedOut = true;
					    listOfUsers[i].source = -1;
					}
				}
			}
			
			// creates memory for the string packet that needs to be sent and temp list string
			char* packet_to_send = malloc(1000*sizeof(char));
			
			if (signedOut == true) 
			{
				server.type = LOGOUT;
				strcpy(server.data, "Succesfully logged out: ");
				strcpy(server.source, client.source);
				int data_string_size = strlen(server.data);
				int packet_members = sprintf(packet_to_send, "LOGOUT_ACK:%d:%s:%s", data_string_size, server.source, server.data);
				packet_to_send[packet_members+1] = '\0';
			}
			else 
			{
				server.type = LOGOUT;
				strcpy(server.data, "Did not log you out. Please try again: ");
				strcpy(server.source, client.source);
				int data_string_size = strlen(server.data);
				int packet_members = sprintf(packet_to_send, "LOGOUT_NAK:%d:%s:%s", data_string_size, server.source, server.data);
				packet_to_send[packet_members+1] = '\0';
			}
			
			// sets size of the server message
			server.size = 1000;
			
			// writes the data to the socket for the client to read
			write(sock, packet_to_send, 1000);
			
			// frees the stored data for the next iteration
			free(packet_to_send);
			
		}
		else if (strcmp(type, "LEAVE_SESS") == 0) 
		{
			
			// detects the rest of the message to get the data
			char *currentUser;
			ptr = strtok(NULL, "\0");
			currentUser = malloc(sizeof(char) * (strlen(ptr)+1));
			strcpy(currentUser, ptr);
			
			bool leftSuccessfully = false;
			bool inSession;
			bool logged_out = false;
			
			// creates memory for the string packet that needs to be sent and temp list string
			char* packet_to_send = malloc(1000*sizeof(char));
			
			
			
			for (int i = 0; i < 3; i++) 
			{
				if (strcmp(listOfUsers[i].id, client.source) == 0) 
				{
				    if(listOfUsers[i].live == false)
				    {
				        printf("user logged out, cannot join\n");
				        logged_out = true;
				        break;
				    }
				    else
				    {
				        listOfUsers[i].lastActivityTime = time(NULL);
				    }
				    
					if (listOfUsers[i].sessionID[0] == NULL) 
					{	
						server.type = LEAVE_SESS;
						strcpy(server.data, "User is not in any session yet, so cannot leave:");
						strcpy(server.source, client.source);
						int data_string_size = strlen(server.data);
						int packet_members = sprintf(packet_to_send, "LEAVE_SESS:%d:%s:%s", data_string_size, server.source, server.data);
						packet_to_send[packet_members+1] = '\0';		
					}
					else 
					{
					    for(int j=0;j<10;j++)
					    {
					        listOfUsers[i].sessionID[j] = NULL;
					    }
						
						
						server.type = LEAVE_SESS;
						strcpy(server.data, "Removed from session:");
						strcpy(server.source, client.source);
						int data_string_size = strlen(server.data);
						int packet_members = sprintf(packet_to_send, "LEAVE_SESS:%d:%s:%s", data_string_size, server.source, server.data);
						packet_to_send[packet_members+1] = '\0';
					}
				}
			}
			if(logged_out)
			{
				server.type = JN_NAK;
				strcpy(server.data, "User logged out, please login again.");
				strcpy(server.source, client.source);
				int data_string_size = strlen(server.data);
				int packet_members = sprintf(packet_to_send, "JN_NAK:%d:%s:%s", data_string_size, server.source, server.data);
				packet_to_send[packet_members+1] = '\0';			    
			}
			// sets size of the server message
			server.size = 1000;
			
			// writes the data to the socket for the client to read
			write(sock, packet_to_send, 1000);
			
			// frees the stored data for the next iteration
			free(packet_to_send);
		}
		else 
		{
			printf("!!!!!!!!!");
		}
	}
}
