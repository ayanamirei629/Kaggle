/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   packet.h
 * Author: huyingge
 *
 * Created on February 7, 2024, 5:26 p.m.
 */

#ifndef PACKET_H
#define PACKET_H
#include <stdio.h>
#include <string.h> 
#include <stdlib.h>
#include <regex.h>

#define BUFFER_SIZE 1100
#define DATA_SIZE 1000

typedef struct packet 
{
    unsigned int total_frag;
    unsigned int frag_no;
    unsigned int size;
    char* filename;
    char filedata[1000];
} Packet;






void convertToText(const Packet *packet, char *result)
{
    //initialize string
    memset(result, 0, BUFFER_SIZE);
    
    int fragTotal_pos = 0;
    sprintf(result, "%d", packet -> total_frag);
    fragTotal_pos = strlen(result);
    memcpy(result + fragTotal_pos, ":", sizeof(char));

    
    int fragNo_pos = fragTotal_pos + 1;
    sprintf(result + fragNo_pos, "%d", packet -> frag_no);
    fragNo_pos = strlen(result);
    memcpy(result + fragNo_pos, ":", sizeof(char));


    int size_pos = fragNo_pos + 1;
    sprintf(result + size_pos, "%d", packet -> size);
    size_pos = strlen(result);
    memcpy(result + size_pos, ":", sizeof(char));

    int name_pos = size_pos + 1;
    sprintf(result + name_pos, "%s", packet -> filename);
    name_pos += strlen(packet -> filename);
    memcpy(result + name_pos, ":", sizeof(char));


    memcpy(result + name_pos + 1, packet -> filedata, sizeof(char) * DATA_SIZE);
    
}



#endif /* PACKET_H */

void convertToPacket(const char *target, Packet *packet) {
    // Temporary storage for the filename to ensure we don't overflow packet->filename
    char tempFilename[500]; //500 char for name

    //parse the string up to the filename
    int parsedItems = sscanf(target, "%u:%u:%u:%[^:]:", &packet->total_frag, &packet->frag_no, &packet->size, tempFilename);

    //check items were successfully parsed
    if (parsedItems != 4) 
    {
        fprintf(stderr, "Failed to parse packet header.\n");
        return; // Indicate failure
    }

    // copy filename
    packet->filename = (char*)malloc(strlen(tempFilename) + 1);
    if (packet->filename == NULL) 
    {
        fprintf(stderr, "filename error\n");
        return;
    }
    
    strcpy(packet->filename, tempFilename);

    // Find pos of data
    const char *start_pos = strchr(target, ':'); // get first :
    for (int i = 0; i < 3; ++i) { // Skip to the fourth colon
        if (start_pos != NULL) start_pos = strchr(start_pos + 1, ':');
    }

    if (start_pos == NULL) {
        fprintf(stderr, "Failed to find start of file data.\n");
        free(packet->filename);
        return;
    }
    start_pos++; // next pos after the :

    // Calculate  length
    int dataLength = packet->size;
    if (dataLength > 1000 || dataLength < 0) {
        fprintf(stderr, "Invalid size\n");
        free(packet->filename);
        return;
    }

    // Copy the data into the packet, being careful with binary data
    memcpy(packet->filedata, start_pos, dataLength);
    
    printf("total_frag = %d,\n frag_no = %d, size = %d"
            ", filename = %s\n", packet->total_frag
            , packet->frag_no, packet->size, packet->filename);
    free(packet->filename);
}

// Function to clean up allocated memory in a packet
void freePacket(Packet *packet) {
    if (packet->filename != NULL) {
        free(packet->filename);
        packet->filename = NULL;
    }
}
    