#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <netdb.h>
#include <unistd.h>
#include <ctype.h>
#include <time.h>

#define BUFFER_SIZE 1100
#define DATA_SIZE 1000    

// struct for each individual packet to be sent
struct packet {
	unsigned int total_frag;
	unsigned int frag_no;	
	unsigned int size;
	char* filename;
	char filedata[1000];
	struct packet* next;
};

int main(int argc, char const *argv[])
{
    if (argc != 3) 
    {
        fprintf(stderr, "deliver <server address> <server port number>\n");
        exit(0);
    }
    
    int port = atoi(argv[2]);
 
    int sockfd;	
    sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    // open socket (DGRAM) Beej's page 75
    if (sockfd == -1) 
    {
        perror("socket");
        exit(1);
    }
    
    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    //port
    server_address.sin_port = htons(atoi(argv[2]));
    //ip
    server_address.sin_addr.s_addr = inet_addr(argv[1]);	
    
    char buffer[BUFFER_SIZE];
    char message[BUFFER_SIZE];
    
    //get user input
    printf("FTP ");
    scanf("%s", message);


    char filename[BUFFER_SIZE] = {0};
    //check the file
    FILE *file;
    file = fopen(message, "r");
    if(file == NULL)
    {
        fprintf(stderr, "File %s not found\n", message);
        close(sockfd);
        exit(1);
    }
    //store address info
    struct addrinfo *address_info; 
    int info = getaddrinfo(argv[1], port, &server_address, &address_info);
    
    //start timer
    clock_t start_send, back;
    start_send = clock();
    // send the message
    sendto(sockfd, "ftp", strlen("ftp"), 0, (const struct sockaddr *)&server_address, sizeof(server_address));
    
    char res[BUFFER_SIZE];
    if((recvfrom(sockfd, res, BUFFER_SIZE, 0
            , NULL, NULL)) == -1) 
    {
        fprintf(stderr, "recvfrom error");
        exit(1);
    }
    back = clock();
    double  rtt= (double) (back - start_send)*1000000 / CLOCKS_PER_SEC;
    printf("RTT: %.2f microsecond.\n",rtt);  

    if(strcmp(res, "yes") == 0) 
    {
        fprintf(stdout, "A file transfer can start\n");
    }
    else
    {
        printf("Not received\n");
    }

    //start transfer
	file = fopen(filename, "rb");
	
    // calculate size of file
	fseek(file, 0, SEEK_END);
	int f_size = ftell(file);
	
	//back to begining
    fseek(file, 0, SEEK_SET);
    
    //calculate total packets
    int fragments = f_size/10000 + 1;
    char packet_data[BUFFER_SIZE];
    
    struct packet *prev_p, *head_p, *cur_p;
    
	//add packets
	for (int i = 1; i <= fragments; i++) 
	{
		
		// creates a new packet with respective memory allocation
		struct packet *temp_p = malloc(sizeof(struct packet));
		
		//set head packet
		if (i == 1) 
		{
			head_p = temp_p;
		}
		//else, set next packet
		else 
		{
			prev_p->next = temp_p;
		}
		
		// stores values
		temp_p->total_frag = fragments;
		temp_p->frag_no = i;
		//read in buffer and store size
		int n = fread(packet_data, 1, 1000, file);
		temp_p->size = n;
		temp_p->filename = filename;
		//store in packet
		memcpy(temp_p->filedata, packet_data, n);
		//prepare for next packet
		temp_p->next = NULL;
		
		// Changes previous packet pointer to new packet
		prev_p = temp_p;
	}    
    
    fclose(file);
    
    //start from head packet and transfer
    cur_p = head_p;
    int total_len = 0;
    //while not til the end of packet, keep sending
    while(cur_p != NULL)
    {
        //length of the packet
        total_len += snprintf(NULL, 0, "%d", cur_p->total_frag);
        total_len += snprintf(NULL, 0, "%d", cur_p->frag_no);
        total_len += snprintf(NULL, 0, "%d", cur_p->size);
        total_len += snprintf(NULL, 0, "%d", cur_p->filename);
        total_len += cur_p->size;
        total_len = 0;
        printf("for packet %d, total size %d \n", cur_p->frag_no, cur_p->size);
        
        //melloc for sending
        char* pack_send = malloc(total_len * sizeof(char));
        
        //fills string
		int pac = sprintf(pack_send, "%d:%d:%d:%s:"
		                , cur_p->total_frag, cur_p->frag_no
		                , cur_p->size, cur_p->filename);
		                
		//copy the data into the string starting from the index calculated above
		memcpy(&pack_send[pac], cur_p->filedata, cur_p->size);		
		
		//send packet
		int sent_packet = sendto(sockfd, pack_send, total_len, 0
		            , (const struct sockaddr *)&server_address, sizeof(server_address));
		if (sent_packet == -1) 
		{
			printf("fail to send'\n");
			return 0;	
		}	
		else
		{
		    printf("send successful for frag number: %d\n", cur_p->frag_no);
		}
		//check receive
		int receive_output = recvfrom(sockfd, res, 999 , 0
		                    , NULL, NULL);
		if (receive_output == -1) 
		{
			printf("Error in receiving\n");
			return 0;
		}		
		else if(strcmp(res, "ACK") == 0)
		{
		    printf("ACK");
		}
		else
		{
		    printf("Not ACK");
		}
		
		//send next packet
		cur_p = cur_p->next;
		//free memory
		free(sent_packet);
    }
    
    
    close(sockfd);
    
    return 0;
}
